import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SolarScene } from "@/components/SolarScene";
import { PlanetPanel } from "@/components/PlanetPanel";
import { ALL_PLANETS, SOLAR, KEPLER } from "@/lib/planets";
import { ShootingStars } from "@/components/ShootingStars";
import { Eye, Rocket } from "lucide-react";

export const Route = createFileRoute("/exploracao")({
  head: () => ({
    meta: [
      { title: "Exploração dos Planetas — NexStationX" },
      {
        name: "description",
        content:
          "Modos de exploração fácil (informativo) e radical (imersivo). Clique em cada planeta para descobrir curiosidades.",
      },
      { property: "og:title", content: "Exploração interativa dos planetas" },
      {
        property: "og:description",
        content: "Detalhes 3D de cada planeta do Sistema Solar e de Kepler-90.",
      },
    ],
  }),
  component: Exploracao,
});

function Exploracao() {
  const [focused, setFocused] = useState<string | null>(null);
  const [hovered, setHovered] = useState<string | null>(null);
  const [tab, setTab] = useState<"solar" | "kepler">("solar");
  const [mode, setMode] = useState<"easy" | "radical">("easy");
  const planets = tab === "solar" ? SOLAR : KEPLER;
  const planet = ALL_PLANETS.find((p) => p.id === focused) ?? null;
  const hoverPlanet = ALL_PLANETS.find((p) => p.id === hovered) ?? null;

  return (
    <main className="relative h-screen w-full overflow-hidden pt-16">
      <div className="absolute inset-0">
        <SolarScene
          planets={planets}
          focusedId={focused}
          onSelectPlanet={setFocused}
          onHoverPlanet={setHovered}
          starColor={tab === "solar" ? 0xffcc66 : 0x88ddff}
          mode={mode}
          showLabels={mode === "easy"}
          showAsteroidBelt={tab === "solar"}
        />
      </div>
      <ShootingStars />

      {!focused && (
        <div className="pointer-events-none absolute left-1/2 top-20 z-10 -translate-x-1/2 text-center animate-fade-up px-4">
          <span className="font-mono text-xs uppercase tracking-[0.3em] text-primary/80">Seção 04</span>
          <h1 className="mt-2 text-4xl font-bold text-gradient">Exploração dos Planetas</h1>
          <p className="mt-2 text-sm text-muted-foreground max-w-md mx-auto">
            Selecione um sistema, escolha o modo e clique no planeta orbitando.
          </p>

          <div className="pointer-events-auto mt-5 flex flex-wrap items-center justify-center gap-3">
            <div className="inline-flex glass rounded-full p-1">
              <TabBtn active={tab === "solar"} onClick={() => setTab("solar")}>
                Sistema Solar
              </TabBtn>
              <TabBtn active={tab === "kepler"} onClick={() => setTab("kepler")}>
                Kepler-90
              </TabBtn>
            </div>

            <div className="inline-flex glass rounded-full p-1">
              <ModeBtn active={mode === "easy"} onClick={() => setMode("easy")} icon={<Eye className="h-3 w-3" />}>
                Observação fácil
              </ModeBtn>
              <ModeBtn
                active={mode === "radical"}
                onClick={() => setMode("radical")}
                icon={<Rocket className="h-3 w-3" />}
              >
                Modo radical
              </ModeBtn>
            </div>
          </div>

          <p className="pointer-events-none mt-3 font-mono text-[10px] uppercase tracking-widest text-muted-foreground/80 max-w-md mx-auto">
            {mode === "easy"
              ? "Câmera ampla · rótulos visíveis · ideal para entender o sistema"
              : "Câmera próxima · FOV imersivo · sinta a escala do cosmos"}
          </p>
        </div>
      )}

      {/* Hover tooltip */}
      {!focused && hoverPlanet && (
        <div className="pointer-events-none absolute left-1/2 bottom-32 z-10 -translate-x-1/2 glass rounded-xl px-4 py-2 animate-fade-in">
          <div className="font-mono text-[10px] uppercase tracking-widest text-primary">{hoverPlanet.name}</div>
          <div className="text-xs text-muted-foreground">Clique para explorar →</div>
        </div>
      )}

      {!focused && (
        <div className="pointer-events-none absolute bottom-8 left-1/2 z-10 -translate-x-1/2 flex flex-wrap justify-center gap-2 animate-fade-up max-w-[90vw]">
          {planets.map((p) => (
            <button
              key={p.id}
              onClick={() => setFocused(p.id)}
              className="pointer-events-auto rounded-full glass px-4 py-2 text-xs font-medium hover:bg-primary/20 hover:scale-105 transition flex items-center gap-2"
            >
              <span
                className="h-2.5 w-2.5 rounded-full"
                style={{ background: p.color, boxShadow: `0 0 10px ${p.color}` }}
              />
              {p.name}
            </button>
          ))}
        </div>
      )}

      <PlanetPanel planet={planet} onClose={() => setFocused(null)} mode={mode} />
    </main>
  );
}

function TabBtn({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full px-4 py-1.5 text-xs font-medium transition ${
        active ? "bg-primary text-primary-foreground shadow-glow" : "text-muted-foreground hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );
}

function ModeBtn({
  active,
  onClick,
  icon,
  children,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full px-3 py-1.5 text-xs font-medium transition flex items-center gap-1.5 ${
        active ? "bg-accent text-accent-foreground shadow-glow" : "text-muted-foreground hover:text-foreground"
      }`}
    >
      {icon}
      {children}
    </button>
  );
}
