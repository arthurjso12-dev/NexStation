import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";
import { Header } from "@/components/Header";
import { CosmoGuide } from "@/components/CosmoGuide";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { Kosmopedia } from "@/components/Kosmopedia";
import { SeasonalBanner } from "@/components/SeasonalBanner";
import { CinematicIntro } from "@/components/CinematicIntro";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-gradient glow-text">404</h1>
        <h2 className="mt-4 text-xl font-semibold">Sinal perdido no espaço</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          A coordenada requisitada não existe nas cartas estelares.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 transition"
          >
            Voltar à órbita
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "NexStationX — Sistema Solar & Kepler-90" },
      {
        name: "description",
        content:
          "Exploração interativa em 3D do Sistema Solar e do sistema Kepler-90. Curiosidades, comparações e linha do tempo do universo.",
      },
      { property: "og:title", content: "NexStationX — Sistema Solar & Kepler-90" },
      {
        property: "og:description",
        content: "Sistema solar interativo com Three.js — descubra os planetas e o gêmeo do nosso sistema.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "NexStationX — Sistema Solar & Kepler-90" },
      { name: "description", content: "Explore celestial bodies with interactive 3D models and engaging facts about our Solar System and Kepler-90." },
      { property: "og:description", content: "Explore celestial bodies with interactive 3D models and engaging facts about our Solar System and Kepler-90." },
      { name: "twitter:description", content: "Explore celestial bodies with interactive 3D models and engaging facts about our Solar System and Kepler-90." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/28b88fd4-7c43-427e-aef9-3b91382e82ce/id-preview-bbdcbf9b--558ef9fd-827d-46fd-b20c-bea6c3e491d7.lovable.app-1776911438433.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/28b88fd4-7c43-427e-aef9-3b91382e82ce/id-preview-bbdcbf9b--558ef9fd-827d-46fd-b20c-bea6c3e491d7.lovable.app-1776911438433.png" },
    ],
    links: [{ rel: "stylesheet", href: appCss }],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return (
    <>
      <CinematicIntro />
      <Header />
      <Breadcrumbs />
      <Outlet />
      <CosmoGuide />
      <Kosmopedia />
      <SeasonalBanner />
    </>
  );
}
