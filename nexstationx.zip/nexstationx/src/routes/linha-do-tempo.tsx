import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { ShootingStars } from "@/components/ShootingStars";

export const Route = createFileRoute("/linha-do-tempo")({
  head: () => ({
    meta: [
      { title: "Linha do Tempo do Universo — NexStationX" },
      {
        name: "description",
        content: "Do Big Bang à descoberta de Kepler-90 — uma jornada animada pelo tempo cósmico.",
      },
      { property: "og:title", content: "Linha do Tempo do Universo" },
      {
        property: "og:description",
        content: "Scroll narrativo através de 13,8 bilhões de anos.",
      },
    ],
  }),
  component: Timeline,
});

const EVENTS = [
  {
    when: "13,8 bilhões de anos atrás",
    title: "Big Bang",
    text: "O universo começa a partir de uma singularidade quente e densa. Em frações de segundo, expande-se cosmicamente — surgem energia, espaço e tempo.",
  },
  {
    when: "13,6 bilhões de anos atrás",
    title: "Formação das primeiras galáxias",
    text: "A gravidade atrai gás e poeira, formando estrelas que se agrupam em galáxias primordiais.",
  },
  {
    when: "4,6 bilhões de anos atrás",
    title: "Nasce o Sistema Solar",
    text: "Uma nuvem molecular colapsa e forma o Sol; os planetas surgem do disco protoplanetário ao seu redor.",
  },
  {
    when: "4,5 bilhões de anos atrás",
    title: "Formação da Terra",
    text: "A Terra se solidifica e, após uma colisão, surge a Lua. Começa a longa jornada que levaria à vida.",
  },
  {
    when: "2009",
    title: "Lançamento do telescópio Kepler",
    text: "A NASA lança a missão Kepler para procurar exoplanetas pelo método de trânsito.",
  },
  {
    when: "2017",
    title: "Descoberta de Kepler-90i",
    text: "Uma rede neural treinada com dados do Kepler descobre o oitavo planeta de Kepler-90 — empatando com o Sistema Solar.",
  },
];

function Timeline() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      if (!containerRef.current) return;
      const items = containerRef.current.querySelectorAll("[data-step]");
      let current = 0;
      const trigger = window.innerHeight * 0.5;
      items.forEach((el, i) => {
        const r = el.getBoundingClientRect();
        if (r.top < trigger) current = i;
      });
      setActive(current);
    };
    window.addEventListener("scroll", onScroll);
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <main className="relative pt-24 pb-32">
      <ShootingStars />

      {/* Sticky progress orb */}
      <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none z-0">
        <div
          className="rounded-full transition-all duration-700"
          style={{
            width: `${80 + active * 60}px`,
            height: `${80 + active * 60}px`,
            background: `radial-gradient(circle, oklch(0.72 0.18 230 / ${0.3 + active * 0.1}), transparent 70%)`,
            filter: "blur(20px)",
          }}
        />
      </div>

      <div className="relative mx-auto max-w-3xl px-6">
        <header className="text-center mb-20 animate-fade-up">
          <span className="font-mono text-xs uppercase tracking-[0.3em] text-primary/80">Seção 05</span>
          <h1 className="mt-2 text-4xl md:text-5xl font-bold text-gradient">Linha do Tempo do Universo</h1>
          <p className="mt-3 text-sm text-muted-foreground">
            Role a página e atravesse 13,8 bilhões de anos.
          </p>
        </header>

        <div ref={containerRef} className="relative">
          {/* vertical line */}
          <div className="absolute left-4 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-primary to-transparent" />

          {EVENTS.map((ev, i) => (
            <div
              key={i}
              data-step={i}
              className={`relative pl-16 pb-24 transition-all duration-700 ${
                i <= active ? "opacity-100 translate-x-0" : "opacity-30 translate-x-4"
              }`}
            >
              <div
                className={`absolute left-2 top-2 h-5 w-5 rounded-full border-2 transition-all duration-500 ${
                  i <= active
                    ? "bg-primary border-primary shadow-glow scale-110"
                    : "bg-background border-border"
                }`}
              />
              <div className="font-mono text-xs uppercase tracking-widest text-primary/80">{ev.when}</div>
              <h2 className="mt-1 text-2xl md:text-3xl font-bold">{ev.title}</h2>
              <p className="mt-3 text-sm md:text-base text-muted-foreground leading-relaxed">{ev.text}</p>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
