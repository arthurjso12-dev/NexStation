import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SolarScene } from "@/components/SolarScene";
import { SOLAR, KEPLER } from "@/lib/planets";
import { ShootingStars } from "@/components/ShootingStars";
import { Slider } from "@/components/ui/slider";
import { ArrowLeftRight, Maximize2, Clock, Ruler } from "lucide-react";

export const Route = createFileRoute("/comparacao")({
  head: () => ({
    meta: [
      { title: "Comparação dos Sistemas — NexStationX" },
      {
        name: "description",
        content: "Compare lado a lado as órbitas, distâncias e durações dos anos do Sistema Solar e Kepler-90.",
      },
      { property: "og:title", content: "Comparação Sistema Solar × Kepler-90" },
      {
        property: "og:description",
        content: "Escala de órbitas, distâncias e tempo de translação interativos.",
      },
    ],
  }),
  component: Comparacao,
});

const ALL = [...SOLAR, ...KEPLER];
const MAX_PERIOD = Math.max(...ALL.map((p) => p.periodDays));
const MAX_RADIUS = Math.max(...ALL.map((p) => p.radiusKm));

function Comparacao() {
  const [swap, setSwap] = useState(false);
  const [metric, setMetric] = useState<"period" | "radius" | "distance">("period");
  const [scale, setScale] = useState(1);

  return (
    <main className="relative min-h-screen pt-24 pb-20 px-4 md:px-8">
      <ShootingStars />
      <div className="relative mx-auto max-w-7xl">
        <header className="text-center mb-10 animate-fade-up">
          <span className="font-mono text-xs uppercase tracking-[0.3em] text-primary/80">Seção 03</span>
          <h1 className="mt-2 text-4xl md:text-5xl font-bold text-gradient">Comparação dos Sistemas</h1>
          <p className="mt-3 text-sm text-muted-foreground max-w-2xl mx-auto">
            Lado a lado: nosso Sistema Solar e Kepler-90. Veja como as órbitas, distâncias e
            durações dos anos diferem em escala real.
          </p>
          <button
            onClick={() => setSwap((s) => !s)}
            className="mt-6 rounded-full bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90 transition shadow-glow inline-flex items-center gap-2"
          >
            <ArrowLeftRight className="h-4 w-4" />
            {swap ? "Restaurar Sol" : "Substituir Sol por Kepler-90"}
          </button>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <SystemCard
            title="Sistema Solar"
            subtitle={swap ? "Estrela: Kepler-90 (G-type)" : "Estrela: Sol (G2V)"}
            planets={SOLAR}
            starColor={swap ? 0x88ddff : 0xffcc66}
          />
          <SystemCard
            title="Kepler-90"
            subtitle="2.545 anos-luz · constelação Draco"
            planets={KEPLER}
            starColor={0x88ddff}
          />
        </div>

        <section className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-4">
          <Metric label="Distância média (UA)" solar="2,57" kepler="0,33" icon={<Ruler className="h-4 w-4" />} />
          <Metric label="Maior período orbital" solar="11,9 anos" kepler="332 dias" icon={<Clock className="h-4 w-4" />} />
          <Metric label="Menor período orbital" solar="88 dias" kepler="7 dias" icon={<Maximize2 className="h-4 w-4" />} />
        </section>

        {/* Dynamic comparison chart */}
        <section className="mt-10 glass rounded-2xl p-6 md:p-8 shadow-card animate-fade-up">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div>
              <h2 className="font-mono text-xs uppercase tracking-widest text-primary mb-1">
                Comparação dinâmica
              </h2>
              <p className="text-sm text-muted-foreground">Escolha a métrica para ver as proporções reais</p>
            </div>
            <div className="inline-flex glass rounded-full p-1">
              <ChartBtn active={metric === "period"} onClick={() => setMetric("period")}>
                Período
              </ChartBtn>
              <ChartBtn active={metric === "radius"} onClick={() => setMetric("radius")}>
                Raio
              </ChartBtn>
              <ChartBtn active={metric === "distance"} onClick={() => setMetric("distance")}>
                Distância
              </ChartBtn>
            </div>
          </div>

          <div className="space-y-3">
            {ALL.map((p, i) => {
              const value =
                metric === "period" ? p.periodDays : metric === "radius" ? p.radiusKm : p.distanceAU * 1000;
              const max = metric === "period" ? MAX_PERIOD : metric === "radius" ? MAX_RADIUS : 5203;
              const pct = Math.max(2, (value / max) * 100);
              const display =
                metric === "period"
                  ? `${p.periodDays.toLocaleString()} dias`
                  : metric === "radius"
                  ? `${p.radiusKm.toLocaleString()} km`
                  : `${p.distanceAU} UA`;
              return (
                <div
                  key={p.id}
                  className="grid grid-cols-[120px_1fr_140px] md:grid-cols-[160px_1fr_160px] items-center gap-3 animate-fade-up"
                  style={{ animationDelay: `${i * 60}ms` }}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span
                      className="h-3 w-3 rounded-full shrink-0"
                      style={{ background: p.color, boxShadow: `0 0 10px ${p.color}` }}
                    />
                    <span className="text-sm font-medium truncate">{p.name}</span>
                  </div>
                  <div className="relative h-3 rounded-full bg-secondary/40 overflow-hidden">
                    <div
                      className="absolute inset-y-0 left-0 rounded-full transition-[width] duration-700 ease-out"
                      style={{
                        width: `${pct}%`,
                        background: `linear-gradient(90deg, ${p.color}, var(--primary))`,
                        boxShadow: `0 0 12px ${p.color}80`,
                      }}
                    />
                  </div>
                  <div className="font-mono text-xs text-muted-foreground text-right">{display}</div>
                </div>
              );
            })}
          </div>

          <div className="mt-6 grid grid-cols-2 gap-3 text-xs text-muted-foreground">
            <div className="rounded-lg border border-border p-3">
              <div className="font-mono uppercase tracking-widest text-primary mb-1">Sistema Solar</div>
              {SOLAR.length} planetas exibidos · escala compactada para visualização
            </div>
            <div className="rounded-lg border border-border p-3">
              <div className="font-mono uppercase tracking-widest text-accent mb-1">Kepler-90</div>
              Sistema completo possui 8 planetas — exibimos os 3 mais notáveis
            </div>
          </div>
        </section>

        {/* Slider interativo de escala */}
        <section className="mt-10 glass rounded-2xl p-6 md:p-8 shadow-card animate-fade-up">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
            <div>
              <h2 className="font-mono text-xs uppercase tracking-widest text-primary mb-1">
                Escala interativa
              </h2>
              <p className="text-sm text-muted-foreground">
                Arraste para ampliar e veja a proporção real de tamanho entre os planetas dos dois sistemas.
              </p>
            </div>
            <div className="font-mono text-xs text-primary">×{scale.toFixed(1)}</div>
          </div>
          <Slider
            value={[scale]}
            onValueChange={(v) => setScale(v[0])}
            min={0.3}
            max={4}
            step={0.1}
            className="mb-6"
          />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              { title: "Sistema Solar", planets: SOLAR, color: "primary" },
              { title: "Kepler-90", planets: KEPLER, color: "accent" },
            ].map((sys) => {
              const maxR = Math.max(...sys.planets.map((p) => p.radiusKm));
              return (
                <div key={sys.title} className="rounded-xl border border-border p-4 bg-secondary/20">
                  <div className={`font-mono text-[10px] uppercase tracking-widest mb-3 text-${sys.color}`}>
                    {sys.title}
                  </div>
                  <div className="flex items-end gap-3 flex-wrap min-h-[120px]">
                    {sys.planets.map((p) => {
                      const size = Math.max(8, (p.radiusKm / maxR) * 80 * scale);
                      return (
                        <div key={p.id} className="flex flex-col items-center gap-1">
                          <div
                            className="rounded-full transition-all duration-300"
                            style={{
                              width: size,
                              height: size,
                              background: `radial-gradient(circle at 30% 30%, ${p.color}, #000)`,
                              boxShadow: `0 0 ${size / 2}px ${p.color}80`,
                            }}
                          />
                          <span className="font-mono text-[9px] text-muted-foreground">{p.name}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </div>
    </main>
  );
}

function SystemCard({
  title,
  subtitle,
  planets,
  starColor,
}: {
  title: string;
  subtitle: string;
  planets: typeof SOLAR;
  starColor: number;
}) {
  return (
    <div className="glass rounded-2xl overflow-hidden shadow-card hover:shadow-glow transition-shadow">
      <div className="px-5 py-4 border-b border-border">
        <h3 className="text-lg font-semibold">{title}</h3>
        <p className="font-mono text-xs text-muted-foreground">{subtitle}</p>
      </div>
      <div className="h-[420px]">
        <SolarScene planets={planets} starColor={starColor} height="100%" />
      </div>
    </div>
  );
}

function Metric({
  label,
  solar,
  kepler,
  icon,
}: {
  label: string;
  solar: string;
  kepler: string;
  icon: React.ReactNode;
}) {
  return (
    <div className="glass rounded-xl p-4 shadow-card hover:scale-[1.02] transition-transform">
      <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
        <span className="text-primary">{icon}</span>
        {label}
      </div>
      <div className="mt-3 flex items-baseline justify-between">
        <div>
          <div className="text-xs text-muted-foreground">Solar</div>
          <div className="text-lg font-semibold">{solar}</div>
        </div>
        <div className="h-8 w-px bg-border" />
        <div className="text-right">
          <div className="text-xs text-muted-foreground">Kepler-90</div>
          <div className="text-lg font-semibold text-primary">{kepler}</div>
        </div>
      </div>
    </div>
  );
}

function ChartBtn({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full px-3 py-1.5 text-xs font-medium transition ${
        active ? "bg-primary text-primary-foreground shadow-glow" : "text-muted-foreground hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );
}
