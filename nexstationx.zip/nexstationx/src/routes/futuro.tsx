import { createFileRoute } from "@tanstack/react-router";
import { ShootingStars } from "@/components/ShootingStars";
import { Telescope, Rocket, Sparkles, Globe2, Atom, Satellite, Cpu } from "lucide-react";

export const Route = createFileRoute("/futuro")({
  head: () => ({
    meta: [
      { title: "Futuro da Exploração Espacial — NexStationX" },
      {
        name: "description",
        content: "Missões atuais, James Webb, exoplanetas e o futuro das viagens interestelares.",
      },
      { property: "og:title", content: "Futuro da Exploração Espacial" },
      {
        property: "og:description",
        content: "James Webb, vida fora da Terra e tecnologias do amanhã.",
      },
    ],
  }),
  component: Futuro,
});

const PROJECTS = [
  {
    icon: <Rocket className="h-5 w-5" />,
    tag: "Em curso · 2026",
    title: "Artemis III — humanos de volta à Lua",
    text: "A primeira missão tripulada a pousar no polo sul lunar desde 1972. Estudará o gelo de água que pode sustentar bases permanentes.",
  },
  {
    icon: <Satellite className="h-5 w-5" />,
    tag: "Operacional · 2024",
    title: "Europa Clipper — caça a oceanos alienígenas",
    text: "Sobrevoa a lua Europa de Júpiter para mapear seu oceano subglacial. Possíveis fontes hidrotermais podem abrigar vida microbiana.",
  },
  {
    icon: <Atom className="h-5 w-5" />,
    tag: "Pesquisa · 2030+",
    title: "Propulsão por fusão nuclear",
    text: "Foguetes de fusão prometem reduzir a viagem a Marte de 9 meses para 6 semanas. Já em testes em laboratório.",
  },
  {
    icon: <Cpu className="h-5 w-5" />,
    tag: "Conceito · 2040+",
    title: "Breakthrough Starshot",
    text: "Microvelas aceleradas por laser viajariam a 20% da velocidade da luz, alcançando Alpha Centauri em ~20 anos.",
  },
  {
    icon: <Globe2 className="h-5 w-5" />,
    tag: "Planejamento · 2030s",
    title: "Mars Base Alpha",
    text: "Bases permanentes em Marte com habitats inflados, energia solar e produção de oxigênio in-situ via MOXIE.",
  },
  {
    icon: <Sparkles className="h-5 w-5" />,
    tag: "Missão · 2027",
    title: "Habitable Worlds Observatory (HWO)",
    text: "Sucessor do Hubble e Webb, projetado para fotografar diretamente exoterras semelhantes à nossa em sistemas como Kepler-90.",
  },
] as const;

function Futuro() {
  return (
    <main className="relative min-h-screen pt-24 pb-20 px-4 md:px-8">
      <ShootingStars />
      <div className="relative mx-auto max-w-6xl">
        <header className="text-center mb-12 animate-fade-up">
          <span className="font-mono text-xs uppercase tracking-[0.3em] text-primary/80">Seção 06</span>
          <h1 className="mt-2 text-4xl md:text-5xl font-bold text-gradient">Futuro da Exploração Espacial</h1>
          <p className="mt-3 text-sm text-muted-foreground max-w-2xl mx-auto">
            O próximo capítulo da humanidade no cosmos — projetos apresentados como se já fossem realidade.
          </p>
        </header>

        {/* Featured: James Webb */}
        <section className="glass rounded-2xl p-8 md:p-12 mb-10 shadow-card relative overflow-hidden animate-fade-up">
          <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-primary/10 blur-3xl animate-pulse-glow" />
          <div className="absolute -left-10 -bottom-20 h-64 w-64 rounded-full bg-accent/10 blur-3xl animate-pulse-glow" />
          <div className="relative grid md:grid-cols-3 gap-6 items-center">
            <div className="md:col-span-1 flex justify-center">
              <div className="relative h-40 w-40">
                <div className="absolute inset-0 rounded-full bg-gradient-stellar opacity-30 blur-2xl animate-pulse-glow" />
                <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 gap-1 rotate-12">
                  {Array.from({ length: 7 }).map((_, i) => (
                    <div
                      key={i}
                      className="rounded-md bg-gradient-to-br from-primary/60 to-accent/40 border border-primary/40"
                    />
                  ))}
                </div>
              </div>
            </div>
            <div className="md:col-span-2">
              <div className="font-mono text-xs uppercase tracking-widest text-primary mb-2 flex items-center gap-2">
                <Telescope className="h-3 w-3" /> Destaque · Operacional desde 2022
              </div>
              <h2 className="text-3xl font-bold">Telescópio Espacial James Webb</h2>
              <p className="mt-3 text-sm md:text-base text-muted-foreground leading-relaxed">
                Observa o universo em infravermelho com sensibilidade sem precedentes — a 1,5 milhão de km
                da Terra, no ponto Lagrange L2. Já analisou atmosferas de exoplanetas como WASP-39b
                detectando dióxido de carbono e está entre os instrumentos mais aptos a procurar
                bioassinaturas em mundos como os de Kepler-90.
              </p>
            </div>
          </div>
        </section>

        {/* Project gallery */}
        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {PROJECTS.map((p, i) => (
            <FutureCard key={i} {...p} delay={i * 80} />
          ))}
        </section>

        <p className="mt-16 text-center font-mono text-xs uppercase tracking-widest text-muted-foreground">
          NexStationX — apresentação para a NASA
        </p>
      </div>
    </main>
  );
}

function FutureCard({
  icon,
  tag,
  title,
  text,
  delay,
}: {
  icon: React.ReactNode;
  tag: string;
  title: string;
  text: string;
  delay: number;
}) {
  return (
    <div
      className="group glass rounded-2xl p-6 shadow-card hover:shadow-glow hover:-translate-y-1 transition-all animate-fade-up relative overflow-hidden"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-primary/5 blur-2xl group-hover:bg-primary/15 transition" />
      <div className="relative">
        <div className="flex items-center justify-between">
          <div className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-primary/15 text-primary group-hover:scale-110 transition-transform">
            {icon}
          </div>
          <span className="font-mono text-[9px] uppercase tracking-widest rounded-full border border-primary/30 px-2 py-0.5 text-primary/80">
            {tag}
          </span>
        </div>
        <h3 className="mt-3 text-lg font-semibold">{title}</h3>
        <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{text}</p>
      </div>
    </div>
  );
}
