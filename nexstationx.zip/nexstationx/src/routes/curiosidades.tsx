import { createFileRoute } from "@tanstack/react-router";
import { ShootingStars } from "@/components/ShootingStars";

export const Route = createFileRoute("/curiosidades")({
  head: () => ({
    meta: [
      { title: "Curiosidades à Parte — NexStationX" },
      {
        name: "description",
        content:
          "Filmes, séries, jogos e cultura pop espacial. A parte mais divertida e curiosa do universo.",
      },
      { property: "og:title", content: "Curiosidades à Parte — NexStationX" },
      {
        property: "og:description",
        content: "Entretenimento espacial: cinema, jogos, livros e fatos malucos.",
      },
    ],
  }),
  component: CuriosidadesPage,
});

type Item = {
  title: string;
  year: string;
  category: string;
  blurb: string;
  fact: string;
  emoji: string;
  url?: string;
  urlLabel?: string;
};

const FILMES: Item[] = [
  {
    title: "Interestelar",
    year: "2014",
    category: "Filme",
    blurb:
      "Christopher Nolan, com consultoria de Kip Thorne, simulou um buraco negro com física real — gerando inclusive um paper científico.",
    fact: "A simulação de Gargantua foi tão precisa que rendeu artigo na revista Classical and Quantum Gravity.",
    emoji: "🎬",
  },
  {
    title: "2001: Uma Odisseia no Espaço",
    year: "1968",
    category: "Filme",
    blurb:
      "Kubrick antecipou tablets, IA conversacional e estações espaciais com gravidade artificial — décadas antes de existirem.",
    fact: "HAL 9000 inspirou gerações de pesquisadores em IA.",
    emoji: "🪐",
  },
  {
    title: "Gravidade",
    year: "2013",
    category: "Filme",
    blurb:
      "Cuarón usou planos-sequência e simulação de microgravidade que se tornaram referência técnica para Hollywood.",
    fact: "Sandra Bullock treinou meses para flutuar de forma convincente.",
    emoji: "🛰️",
  },
  {
    title: "The Expanse",
    year: "2015–22",
    category: "Série",
    blurb:
      "Naves usam thrust real, gravidade por aceleração e o efeito Coriolis afeta bebidas. Ciência dura levada a sério.",
    fact: "Cientistas da NASA citam a série em palestras sobre colonização.",
    emoji: "📺",
  },
];

const JOGOS: Item[] = [
  {
    title: "Kerbal Space Program",
    year: "2015",
    category: "Jogo",
    blurb:
      "Simulador de foguetes com física newtoniana real. Usado por engenheiros da SpaceX e NASA para ensinar mecânica orbital.",
    fact: "Elon Musk recomendou publicamente o jogo.",
    emoji: "🚀",
    url: "https://store.steampowered.com/app/220200/Kerbal_Space_Program/",
    urlLabel: "Steam",
  },
  {
    title: "Outer Wilds",
    year: "2019",
    category: "Jogo",
    blurb:
      "Sistema solar em miniatura com órbitas reais, supernovas e loops temporais. Vencedor do BAFTA de Game of the Year.",
    fact: "Cada planeta tem física e atmosfera completamente simuladas.",
    emoji: "🌌",
    url: "https://store.steampowered.com/app/753640/Outer_Wilds/",
    urlLabel: "Steam",
  },
  {
    title: "No Man's Sky",
    year: "2016",
    category: "Jogo",
    blurb:
      "18 quintilhões de planetas gerados proceduralmente. Cada estrela visível é visitável.",
    fact: "Universo maior que átomos no corpo humano.",
    emoji: "🌍",
    url: "https://www.nomanssky.com/",
    urlLabel: "Site oficial",
  },
  {
    title: "Elite Dangerous",
    year: "2014",
    category: "Jogo",
    blurb:
      "Modela 1:1 a Via Láctea com 400 bilhões de sistemas estelares. Jogadores já descobriram nebulosas reais antes dos astrônomos.",
    fact: "Usa o catálogo Hipparcos da ESA como base estelar.",
    emoji: "✨",
    url: "https://www.elitedangerous.com/",
    urlLabel: "Site oficial",
  },
];

const CULTURA: Item[] = [
  {
    title: "David Bowie — Space Oddity",
    year: "1969",
    category: "Música",
    blurb:
      "Lançada 9 dias antes do pouso da Apollo 11. A BBC só tocou depois do retorno seguro dos astronautas.",
    fact: "Chris Hadfield gravou cover na ISS em 2013.",
    emoji: "🎵",
  },
  {
    title: "O Guia do Mochileiro das Galáxias",
    year: "1979",
    category: "Livro",
    blurb:
      "Douglas Adams ensinou que a resposta é 42 e que toalhas são o item mais essencial do universo.",
    fact: "25 de maio é o Dia da Toalha em sua homenagem.",
    emoji: "📚",
  },
  {
    title: "Cosmos — Carl Sagan",
    year: "1980",
    category: "Documentário",
    blurb:
      "Série que apresentou o universo a 500 milhões de pessoas em 60 países. Reformulou divulgação científica.",
    fact: "Voyager carrega o Disco Dourado idealizado por Sagan.",
    emoji: "🌠",
  },
  {
    title: "LEGO Saturn V",
    year: "2017",
    category: "Cultura",
    blurb:
      "1.969 peças (homenagem a 1969). Foguete em escala 1:110 com módulos lunares destacáveis.",
    fact: "Vendeu mais de 500 mil unidades em 2 anos.",
    emoji: "🧱",
  },
];

function Card({ item }: { item: Item }) {
  return (
    <article className="group relative overflow-hidden rounded-2xl glass p-6 transition hover:scale-[1.02] hover:shadow-glow flex flex-col">
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="text-4xl">{item.emoji}</div>
        <span className="font-mono text-[10px] uppercase tracking-widest text-primary/80 rounded-full bg-primary/10 px-2 py-1">
          {item.category} · {item.year}
        </span>
      </div>
      <h3 className="text-lg font-semibold text-foreground mb-2">{item.title}</h3>
      <p className="text-sm text-muted-foreground leading-relaxed mb-3">{item.blurb}</p>
      <div className="border-t border-border/40 pt-3 mt-auto">
        <p className="text-xs text-primary/90 italic">💡 {item.fact}</p>
        {item.url && (
          <a
            href={item.url}
            target="_blank"
            rel="noreferrer"
            className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-[10px] font-mono uppercase tracking-widest text-primary hover:bg-primary/20 transition"
          >
            {item.urlLabel ?? "Acessar"} ↗
          </a>
        )}
      </div>
    </article>
  );
}

function Section({ title, subtitle, items }: { title: string; subtitle: string; items: Item[] }) {
  return (
    <section className="relative px-6 py-16 max-w-7xl mx-auto">
      <div className="mb-10">
        <span className="font-mono text-xs uppercase tracking-[0.4em] text-primary/80">{subtitle}</span>
        <h2 className="mt-2 text-3xl md:text-4xl font-bold text-gradient">{title}</h2>
      </div>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {items.map((it) => (
          <Card key={it.title} item={it} />
        ))}
      </div>
    </section>
  );
}

function CuriosidadesPage() {
  return (
    <main className="relative min-h-screen pt-24 pb-32">
      <div className="fixed inset-0 -z-10">
        <ShootingStars />
      </div>

      <header className="relative px-6 max-w-7xl mx-auto text-center pb-8 animate-fade-up">
        <span className="font-mono text-xs uppercase tracking-[0.4em] text-primary/80">
          Entretenimento Cósmico
        </span>
        <h1 className="mt-4 text-5xl md:text-6xl font-bold text-gradient glow-text">
          Curiosidades à Parte
        </h1>
        <p className="mt-4 max-w-2xl mx-auto text-sm md:text-base text-muted-foreground">
          O espaço inspira filmes, jogos, músicas e livros que moldam gerações. Aqui reunimos
          obras que fazem ciência soar como aventura.
        </p>
      </header>

      <Section title="Cinema & TV" subtitle="Tela grande" items={FILMES} />

      <div className="relative h-32 overflow-hidden">
        <ShootingStars />
      </div>

      <Section title="Videogames" subtitle="Jogue o universo" items={JOGOS} />

      <div className="relative h-32 overflow-hidden">
        <ShootingStars />
      </div>

      <Section title="Música, Livros & Cultura" subtitle="Pop estelar" items={CULTURA} />

    </main>
  );
}
