import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { ShootingStars } from "@/components/ShootingStars";
import { SolarScene } from "@/components/SolarScene";
import { SOLAR } from "@/lib/planets";
import { AsteroidGame } from "@/components/AsteroidGame";

export const Route = createFileRoute("/asteroides")({
  head: () => ({
    meta: [
      { title: "Asteroides — História do Universo · NexStationX" },
      {
        name: "description",
        content:
          "A linha do tempo dos asteroides: do disco protoplanetário ao cinturão atual e impactos que moldaram a Terra.",
      },
      { property: "og:title", content: "Asteroides — A história silenciosa do Sistema Solar" },
      {
        property: "og:description",
        content: "Descubra como surgiu o cinturão de asteroides e os eventos que mudaram a vida na Terra.",
      },
    ],
  }),
  component: Asteroides,
});

const TIMELINE = [
  {
    when: "4,6 bilhões de anos atrás",
    title: "Disco protoplanetário",
    text: "O Sol recém-formado é cercado por um disco de gás e poeira. Pequenos grãos colidem e se aglomeram — nascem os primeiros planetesimais, sementes dos planetas e dos asteroides.",
    tone: "from-primary/40 to-accent/30",
  },
  {
    when: "4,5 bilhões de anos atrás",
    title: "A formação interrompida",
    text: "A gravidade de Júpiter perturba a região entre Marte e Júpiter, impedindo que os planetesimais ali se unam para formar um planeta. Resta um anel de rocha e metal: o cinturão de asteroides.",
    tone: "from-accent/40 to-primary/20",
  },
  {
    when: "4,1 a 3,8 bilhões de anos atrás",
    title: "Bombardeio Pesado Tardio",
    text: "Uma chuva intensa de asteroides atinge os planetas internos. Cratera Aitken na Lua e a maioria das bacias lunares datam dessa época. A Terra também foi marcada — mas a tectônica apagou as cicatrizes.",
    tone: "from-primary/30 to-accent/40",
  },
  {
    when: "66 milhões de anos atrás",
    title: "Impacto de Chicxulub",
    text: "Um asteroide de ~10 km atinge a península de Yucatán. A extinção em massa que se segue elimina 75% das espécies — incluindo os dinossauros não-aviários — e abre caminho para a era dos mamíferos.",
    tone: "from-destructive/40 to-accent/20",
  },
  {
    when: "1801",
    title: "Descoberta de Ceres",
    text: "Giuseppe Piazzi descobre Ceres, o primeiro e maior objeto do cinturão de asteroides. Hoje classificado como planeta-anão, contém ~1/3 da massa total do cinturão.",
    tone: "from-primary/40 to-accent/30",
  },
  {
    when: "2023",
    title: "Missão OSIRIS-REx",
    text: "A NASA traz à Terra amostras do asteroide Bennu — moléculas orgânicas e água presas em rocha primitiva, peças do quebra-cabeça da origem da vida.",
    tone: "from-accent/40 to-primary/40",
  },
] as const;

function Asteroides() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      if (!containerRef.current) return;
      const items = containerRef.current.querySelectorAll("[data-step]");
      let current = 0;
      const trigger = window.innerHeight * 0.5;
      items.forEach((el, i) => {
        const r = el.getBoundingClientRect();
        if (r.top < trigger) current = i;
      });
      setActive(current);
    };
    window.addEventListener("scroll", onScroll);
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <main className="relative pt-24 pb-32 min-h-screen">
      <ShootingStars />

      {/* Background scene with belt */}
      <div className="fixed inset-0 top-16 -z-10 opacity-60">
        <SolarScene planets={SOLAR} starColor={0xffcc66} showAsteroidBelt />
      </div>

      <div className="relative mx-auto max-w-3xl px-6">
        <header className="text-center mb-16 animate-fade-up">
          <span className="font-mono text-xs uppercase tracking-[0.3em] text-primary/80">Seção 05 · A</span>
          <h1 className="mt-2 text-4xl md:text-5xl font-bold text-gradient">Asteroides</h1>
          <p className="mt-3 text-sm md:text-base text-muted-foreground">
            Os fósseis do Sistema Solar — pedaços do passado que carregam pistas sobre a origem da vida.
          </p>
          <div className="mt-6 grid grid-cols-3 gap-3 max-w-md mx-auto">
            <Stat label="Conhecidos" value="1,3 mi+" />
            <Stat label="No cinturão" value="~960 km" sub="diâmetro de Ceres" />
            <Stat label="Visitados" value="14" />
          </div>
        </header>

        <div className="mb-16 animate-fade-up">
          <AsteroidGame />
        </div>

        <div ref={containerRef} className="relative">
          <div className="absolute left-4 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-primary to-transparent" />
          {TIMELINE.map((ev, i) => (
            <div
              key={i}
              data-step={i}
              className={`relative pl-16 pb-24 transition-all duration-700 ${
                i <= active ? "opacity-100 translate-x-0" : "opacity-30 translate-x-4"
              }`}
            >
              <div
                className={`absolute left-2 top-2 h-5 w-5 rounded-full border-2 transition-all duration-500 ${
                  i <= active ? "bg-primary border-primary shadow-glow scale-110" : "bg-background border-border"
                }`}
              />
              <div className="font-mono text-xs uppercase tracking-widest text-primary/80">{ev.when}</div>
              <h2 className="mt-1 text-2xl md:text-3xl font-bold">{ev.title}</h2>
              <div
                className={`mt-3 rounded-2xl glass p-5 shadow-card relative overflow-hidden bg-gradient-to-br ${ev.tone}`}
              >
                <p className="text-sm md:text-base text-foreground/90 leading-relaxed">{ev.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}

function Stat({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="glass rounded-xl p-3">
      <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      <div className="mt-1 text-lg font-bold text-gradient">{value}</div>
      {sub && <div className="font-mono text-[9px] text-muted-foreground">{sub}</div>}
    </div>
  );
}
