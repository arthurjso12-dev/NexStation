import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SolarScene } from "@/components/SolarScene";
import { PlanetPanel } from "@/components/PlanetPanel";
import { KEPLER } from "@/lib/planets";

export const Route = createFileRoute("/kepler-90")({
  head: () => ({
    meta: [
      { title: "Kepler-90 — NexStationX" },
      {
        name: "description",
        content: "Explore os planetas do sistema Kepler-90, descoberto pela NASA com auxílio de IA.",
      },
      { property: "og:title", content: "Kepler-90 — NexStationX" },
      {
        property: "og:description",
        content: "O primeiro sistema com 8 planetas conhecidos, a 2545 anos-luz da Terra.",
      },
    ],
  }),
  component: KeplerPage,
});

function KeplerPage() {
  const [focused, setFocused] = useState<string | null>(null);
  const planet = KEPLER.find((p) => p.id === focused) ?? null;

  return (
    <main className="relative h-screen w-full overflow-hidden pt-16">
      <div className="absolute inset-0">
        <SolarScene
          planets={KEPLER}
          focusedId={focused}
          onSelectPlanet={setFocused}
          starColor={0x88ddff}
        />
      </div>
      {!focused && (
        <div className="pointer-events-none absolute left-8 top-24 z-10 max-w-md animate-fade-up">
          <span className="font-mono text-xs uppercase tracking-[0.3em] text-primary/80">Seção 02</span>
          <h1 className="mt-2 text-4xl font-bold text-gradient">Kepler-90</h1>
          <p className="mt-3 text-sm text-muted-foreground">
            Sistema gêmeo do nosso, na constelação de Draco. Apresentando{" "}
            <strong className="text-foreground">Kepler-90b</strong>,{" "}
            <strong className="text-foreground">Kepler-90g</strong> e{" "}
            <strong className="text-foreground">Kepler-90i</strong>.
          </p>
        </div>
      )}
      <PlanetPanel planet={planet} onClose={() => setFocused(null)} />
    </main>
  );
}
