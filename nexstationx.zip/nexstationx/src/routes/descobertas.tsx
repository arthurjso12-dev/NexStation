import { createFileRoute } from "@tanstack/react-router";
import { ShootingStars } from "@/components/ShootingStars";

export const Route = createFileRoute("/descobertas")({
  head: () => ({
    meta: [
      { title: "Descobertas do Espaço — NexStationX" },
      {
        name: "description",
        content:
          "Linha do tempo cronológica das maiores descobertas espaciais da humanidade — de Galileu ao James Webb.",
      },
      { property: "og:title", content: "Descobertas do Espaço — NexStationX" },
      {
        property: "og:description",
        content: "Da invenção do telescópio aos exoplanetas: a história ilustrada do cosmos.",
      },
    ],
  }),
  component: DescobertasPage,
});

type Discovery = {
  year: string;
  title: string;
  who: string;
  body: string;
  era: "Pré-Espacial" | "Era Espacial" | "Era Robótica" | "Era Moderna";
  image: string;
  imageAlt: string;
};

const DISCOVERIES: Discovery[] = [
  {
    year: "1610",
    title: "Galileu observa as luas de Júpiter",
    who: "Galileu Galilei",
    body: "Com seu telescópio caseiro, Galileu identifica Io, Europa, Ganimedes e Calisto — provando que nem tudo orbita a Terra. Foi o golpe final no modelo geocêntrico.",
    era: "Pré-Espacial",
    image:
      "https://images.unsplash.com/photo-1614314107768-6018061e5e4d?w=800&auto=format&fit=crop&q=80",
    imageAlt: "Júpiter visto através de um telescópio",
  },
  {
    year: "1687",
    title: "Newton publica a Lei da Gravitação",
    who: "Isaac Newton",
    body: "Os Principia explicam por que planetas orbitam o Sol. Pela primeira vez, a física da Terra é a mesma do céu.",
    era: "Pré-Espacial",
    image:
      "https://images.unsplash.com/photo-1532968961962-8a0cb3a2d4f5?w=800&auto=format&fit=crop&q=80",
    imageAlt: "Maçã caindo simbolizando a gravidade",
  },
  {
    year: "1781",
    title: "Descoberta de Urano",
    who: "William Herschel",
    body: "Primeiro planeta descoberto na era do telescópio. Dobra o tamanho conhecido do Sistema Solar.",
    era: "Pré-Espacial",
    image:
      "https://images.unsplash.com/photo-1614642264762-d0a3b8bf3700?w=800&auto=format&fit=crop&q=80",
    imageAlt: "Planeta azul-esverdeado Urano",
  },
  {
    year: "1846",
    title: "Netuno é descoberto matematicamente",
    who: "Le Verrier & Galle",
    body: "Antes de ser visto, Netuno foi previsto a partir de perturbações na órbita de Urano. Triunfo da matemática aplicada.",
    era: "Pré-Espacial",
    image:
      "https://images.unsplash.com/photo-1614314266357-8f3b1ddc8b07?w=800&auto=format&fit=crop&q=80",
    imageAlt: "Netuno azul profundo",
  },
  {
    year: "1957",
    title: "Sputnik 1 — o primeiro satélite artificial",
    who: "União Soviética",
    body: "Uma esfera metálica de 58 cm orbita a Terra emitindo bipes que mudaram o século XX. Inicia a Era Espacial.",
    era: "Era Espacial",
    image:
      "https://images.unsplash.com/photo-1517976487492-5750f3195933?w=800&auto=format&fit=crop&q=80",
    imageAlt: "Satélite Sputnik no espaço",
  },
  {
    year: "1961",
    title: "Yuri Gagarin — primeiro humano no espaço",
    who: "Yuri Gagarin (URSS)",
    body: "A bordo da Vostok 1, Gagarin completa uma órbita em 108 minutos. Sua frase 'Poyekhali!' (Vamos!) entra para a história.",
    era: "Era Espacial",
    image:
      "https://images.unsplash.com/photo-1457364887197-9150188c107b?w=800&auto=format&fit=crop&q=80",
    imageAlt: "Cosmonauta com capacete",
  },
  {
    year: "1963",
    title: "Valentina Tereshkova — primeira mulher no espaço",
    who: "Valentina Tereshkova (URSS)",
    body: "A bordo da Vostok 6, completou 48 órbitas em quase 3 dias — mais tempo do que todos os astronautas americanos somados até então.",
    era: "Era Espacial",
    image:
      "https://images.unsplash.com/photo-1454789548928-9efd52dc4031?w=800&auto=format&fit=crop&q=80",
    imageAlt: "Mulher astronauta",
  },
  {
    year: "1969",
    title: "Apollo 11 — humanos na Lua",
    who: "Armstrong, Aldrin & Collins",
    body: "“Um pequeno passo para o homem, um salto gigantesco para a humanidade.” 600 milhões assistem ao vivo.",
    era: "Era Espacial",
    image:
      "https://images.unsplash.com/photo-1614728263952-84ea256f9679?w=800&auto=format&fit=crop&q=80",
    imageAlt: "Pegada de astronauta na Lua",
  },
  {
    year: "1977",
    title: "Voyager 1 & 2 são lançadas",
    who: "NASA",
    body: "Sondas projetadas para explorar planetas externos. Voyager 1 é o objeto humano mais distante já construído — agora no espaço interestelar.",
    era: "Era Robótica",
    image:
      "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&auto=format&fit=crop&q=80",
    imageAlt: "Sonda espacial no escuro do espaço",
  },
  {
    year: "1990",
    title: "Telescópio Hubble entra em órbita",
    who: "NASA & ESA",
    body: "Acima da atmosfera, o Hubble revela campos profundos com galáxias do início do universo. Recalibra a idade do cosmos.",
    era: "Era Robótica",
    image:
      "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=800&auto=format&fit=crop&q=80",
    imageAlt: "Galáxia espiral distante",
  },
  {
    year: "1995",
    title: "Primeiro exoplaneta ao redor de estrela tipo solar",
    who: "Mayor & Queloz",
    body: "51 Pegasi b — um Júpiter quente — confirma que existem outros sistemas planetários. Rendeu o Nobel de Física em 2019.",
    era: "Era Robótica",
    image:
      "https://images.unsplash.com/photo-1610296669228-602fa827fc1f?w=800&auto=format&fit=crop&q=80",
    imageAlt: "Exoplaneta gigante perto de estrela",
  },
  {
    year: "2012",
    title: "Curiosity pousa em Marte",
    who: "NASA / JPL",
    body: "O rover de 1 tonelada usa o inédito 'Sky Crane'. Confirma que Marte teve condições habitáveis no passado.",
    era: "Era Moderna",
    image:
      "https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?w=800&auto=format&fit=crop&q=80",
    imageAlt: "Superfície marciana avermelhada",
  },
  {
    year: "2017",
    title: "Kepler-90 — IA descobre o 8º planeta",
    who: "NASA + Google AI",
    body: "Uma rede neural varre dados do Kepler e encontra Kepler-90i, tornando o sistema o primeiro empate com o Solar em número de planetas.",
    era: "Era Moderna",
    image:
      "https://images.unsplash.com/photo-1532543491484-63e29b3c1f5b?w=800&auto=format&fit=crop&q=80",
    imageAlt: "Sistema planetário distante",
  },
  {
    year: "2019",
    title: "Primeira foto de um buraco negro",
    who: "Event Horizon Telescope",
    body: "M87* é capturado por uma rede de radiotelescópios do tamanho da Terra. Albert Einstein, novamente, estava certo.",
    era: "Era Moderna",
    image:
      "https://images.unsplash.com/photo-1465101162946-4377e57745c3?w=800&auto=format&fit=crop&q=80",
    imageAlt: "Imagem alaranjada de buraco negro",
  },
  {
    year: "2022",
    title: "James Webb revela o universo profundo",
    who: "NASA / ESA / CSA",
    body: "Em infravermelho, o JWST fotografa galáxias formadas 300 milhões de anos após o Big Bang e analisa atmosferas de exoplanetas.",
    era: "Era Moderna",
    image:
      "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=800&auto=format&fit=crop&q=80",
    imageAlt: "Nebulosa colorida do James Webb",
  },
  {
    year: "2024",
    title: "Europa Clipper rumo à lua de Júpiter",
    who: "NASA",
    body: "Lançada para investigar se o oceano sob a crosta de gelo de Europa pode abrigar vida. Chegada prevista para 2030.",
    era: "Era Moderna",
    image:
      "https://images.unsplash.com/photo-1454789591675-556c287e39e2?w=800&auto=format&fit=crop&q=80",
    imageAlt: "Sonda espacial em frente a Júpiter",
  },
];

const ERAS: Discovery["era"][] = [
  "Pré-Espacial",
  "Era Espacial",
  "Era Robótica",
  "Era Moderna",
];

function eraColor(era: Discovery["era"]) {
  switch (era) {
    case "Pré-Espacial":
      return "from-amber-500/20 to-amber-300/5 border-amber-400/30 text-amber-300";
    case "Era Espacial":
      return "from-rose-500/20 to-rose-300/5 border-rose-400/30 text-rose-300";
    case "Era Robótica":
      return "from-cyan-500/20 to-cyan-300/5 border-cyan-400/30 text-cyan-300";
    case "Era Moderna":
      return "from-violet-500/20 to-violet-300/5 border-violet-400/30 text-violet-300";
  }
}

function DescobertasPage() {
  return (
    <main className="relative min-h-screen pt-24 pb-32">
      <div className="fixed inset-0 -z-10">
        <ShootingStars />
      </div>

      <header className="relative px-6 max-w-5xl mx-auto text-center pb-12 animate-fade-up">
        <span className="font-mono text-xs uppercase tracking-[0.4em] text-primary/80">
          História do Cosmos
        </span>
        <h1 className="mt-4 text-5xl md:text-6xl font-bold text-gradient glow-text">
          Descobertas do Espaço
        </h1>
        <p className="mt-4 max-w-2xl mx-auto text-sm md:text-base text-muted-foreground">
          De um telescópio rudimentar em Pádua, em 1610, a redes neurais que descobrem novos
          mundos. Quatro séculos transformaram nossa visão do universo.
        </p>
        <div className="mt-6 flex flex-wrap gap-2 justify-center">
          {ERAS.map((e) => (
            <span
              key={e}
              className={`rounded-full border px-3 py-1 text-[10px] font-mono uppercase tracking-widest bg-gradient-to-br ${eraColor(
                e
              )}`}
            >
              {e}
            </span>
          ))}
        </div>
      </header>

      <section className="relative max-w-5xl mx-auto px-6">
        {/* Linha vertical central */}
        <div className="absolute left-6 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-primary/40 to-transparent" />

        <ol className="space-y-12">
          {DISCOVERIES.map((d, i) => {
            const left = i % 2 === 0;
            return (
              <li
                key={d.year}
                className={`relative md:grid md:grid-cols-2 md:gap-10 items-center animate-fade-up ${
                  left ? "" : "md:[&>*:first-child]:order-2"
                }`}
                style={{ animationDelay: `${i * 60}ms` }}
              >
                {/* Imagem */}
                <div className="pl-12 md:pl-0">
                  <div className="overflow-hidden rounded-2xl border border-border/50 shadow-card group">
                    <img
                      src={d.image}
                      alt={d.imageAlt}
                      loading="lazy"
                      className="w-full h-56 object-cover transition duration-700 group-hover:scale-105"
                    />
                  </div>
                </div>

                {/* Texto + dot */}
                <div className="relative pl-12 md:pl-0 mt-4 md:mt-0">
                  {/* Dot na linha */}
                  <span className="absolute left-4 md:left-auto md:right-full md:mr-[-9px] top-2 h-4 w-4 rounded-full bg-primary shadow-glow ring-4 ring-background" />
                  <div
                    className={`rounded-2xl border bg-gradient-to-br p-6 ${eraColor(d.era)}`}
                  >
                    <div className="flex items-center justify-between gap-3 mb-2">
                      <span className="font-mono text-3xl font-bold">{d.year}</span>
                      <span className="font-mono text-[10px] uppercase tracking-widest opacity-80">
                        {d.era}
                      </span>
                    </div>
                    <h3 className="text-xl font-semibold text-foreground mb-1">{d.title}</h3>
                    <p className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-3">
                      {d.who}
                    </p>
                    <p className="text-sm text-foreground/85 leading-relaxed">{d.body}</p>
                  </div>
                </div>
              </li>
            );
          })}
        </ol>
      </section>

    </main>
  );
}
