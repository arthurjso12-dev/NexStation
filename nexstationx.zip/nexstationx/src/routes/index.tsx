import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SolarScene } from "@/components/SolarScene";
import { PlanetPanel } from "@/components/PlanetPanel";
import { ALL_PLANETS, SOLAR } from "@/lib/planets";
import { ShootingStars } from "@/components/ShootingStars";
import { InterstellarTrailer } from "@/components/InterstellarTrailer";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "NexStationX — Início" },
      {
        name: "description",
        content: "Explore em 3D o Sistema Solar e o sistema Kepler-90 com Three.js.",
      },
    ],
  }),
  component: Index,
});

type Card = {
  to: string;
  label: string;
  desc: string;
  preview: "solar" | "kepler" | "iss" | "discovery" | "culture" | "future";
};

const QUICK_NAV: Card[] = [
  { to: "/sistema-solar", label: "Sistema Solar", desc: "Tour narrativo pelos planetas em 3D", preview: "solar" },
  { to: "/kepler-90", label: "Kepler-90", desc: "O sistema gêmeo descoberto por IA", preview: "kepler" },
  { to: "/ao-vivo", label: "Câmera ao Vivo", desc: "ISS transmitindo da órbita agora", preview: "iss" },
  { to: "/descobertas", label: "Descobertas", desc: "400 anos de história do cosmos", preview: "discovery" },
  { to: "/curiosidades", label: "Curiosidades", desc: "Filmes, jogos e cultura espacial", preview: "culture" },
  { to: "/futuro", label: "Futuro", desc: "Missões, exoplanetas e além", preview: "future" },
];

function Preview({ kind }: { kind: Card["preview"] }) {
  const base = "absolute inset-0 overflow-hidden rounded-xl";
  if (kind === "solar")
    return (
      <div className={`${base} bg-gradient-to-br from-[#0B0F2A] to-[#1a1240]`}>
        <div className="absolute left-1/2 top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#FFD166] shadow-[0_0_20px_#FFD166]" />
        {[28, 44, 64].map((r, i) => (
          <div
            key={i}
            className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border border-primary/20"
            style={{ width: r * 2, height: r * 2, animation: `orbit-spin ${8 + i * 6}s linear infinite` }}
          >
            <div
              className="absolute h-2 w-2 rounded-full"
              style={{
                top: -4,
                left: r - 4,
                background: ["#9ad9ff", "#ff9966", "#ffd166"][i],
                boxShadow: `0 0 8px ${["#9ad9ff", "#ff9966", "#ffd166"][i]}`,
              }}
            />
          </div>
        ))}
      </div>
    );
  if (kind === "kepler")
    return (
      <div className={`${base} bg-gradient-to-br from-[#1a1240] to-[#6C47FF]/40`}>
        <div className="absolute inset-0 opacity-60" style={{
          background: "radial-gradient(circle at 30% 50%, #88ddff 0%, transparent 30%), radial-gradient(circle at 70% 50%, #6C47FF 0%, transparent 35%)",
        }} />
        <div className="absolute inset-0 flex items-center justify-center text-3xl animate-pulse-glow">✨</div>
      </div>
    );
  if (kind === "iss")
    return (
      <div className={`${base} bg-gradient-to-br from-[#0a1f3a] to-[#0B0F2A]`}>
        <div className="absolute inset-0 opacity-40" style={{
          backgroundImage: "linear-gradient(180deg, #1e3a5f 0%, #0B0F2A 70%)",
        }} />
        <div className="absolute top-3 left-3 flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-full bg-rose-500 animate-ping" />
          <span className="h-2 w-2 -ml-3 rounded-full bg-rose-500" />
          <span className="font-mono text-[9px] uppercase tracking-widest text-rose-300">LIVE</span>
        </div>
        <div className="absolute bottom-4 left-0 right-0 text-center text-2xl">🛰️</div>
      </div>
    );
  if (kind === "discovery")
    return (
      <div className={`${base} bg-gradient-to-br from-[#1a1a3e] to-[#3a1a5e]`}>
        <div className="absolute inset-x-4 top-1/2 h-px bg-primary/40" />
        {[20, 50, 80].map((x, i) => (
          <div
            key={i}
            className="absolute top-1/2 h-2 w-2 -translate-y-1/2 rounded-full bg-[#FFD166] shadow-glow"
            style={{ left: `${x}%`, animation: `pulse-glow ${2 + i}s ease-in-out infinite` }}
          />
        ))}
        <div className="absolute bottom-3 right-3 text-2xl">🔭</div>
      </div>
    );
  if (kind === "culture")
    return (
      <div className={`${base} bg-gradient-to-br from-[#3a1a5e] to-[#6C47FF]/30`}>
        <div className="absolute inset-0 grid grid-cols-3 gap-1 p-3 opacity-60">
          {["🎬", "🎮", "📚", "🎵", "🚀", "👽"].map((e, i) => (
            <div key={i} className="flex items-center justify-center text-xl animate-float" style={{ animationDelay: `${i * 0.3}s` }}>
              {e}
            </div>
          ))}
        </div>
      </div>
    );
  return (
    <div className={`${base} bg-gradient-to-br from-[#0B0F2A] to-[#6C47FF]/40`}>
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="relative h-16 w-16 rounded-full border-2 border-[#FFD166] animate-pulse-glow" />
      </div>
      <div className="absolute bottom-3 right-3 text-2xl animate-float">🚀</div>
    </div>
  );
}

function Index() {
  const [focused, setFocused] = useState<string | null>(null);
  const [showHint, setShowHint] = useState(true);
  const planet = ALL_PLANETS.find((p) => p.id === focused) ?? null;

  useEffect(() => {
    const t = setTimeout(() => setShowHint(false), 5000);
    return () => clearTimeout(t);
  }, []);

  return (
    <main className="relative w-full">
      <section className="relative h-screen w-full overflow-hidden">
        <div className="absolute inset-0">
          <SolarScene planets={SOLAR} focusedId={focused} onSelectPlanet={setFocused} starColor={0x88bbff} />
        </div>

        <ShootingStars />

        {!focused && (
          <div className="pointer-events-none absolute inset-x-0 top-24 z-10 flex flex-col items-center text-center px-6 animate-fade-up">
            <span className="font-mono text-xs uppercase tracking-[0.4em] text-primary/80">
              Apresentação · NASA
            </span>
            <h1 className="mt-4 text-5xl md:text-7xl font-bold text-gradient glow-text">NexStationX</h1>
            <p className="mt-4 max-w-xl text-sm md:text-base text-muted-foreground">
              Uma jornada interativa pelo Sistema Solar e por Kepler-90 — o primeiro sistema
              conhecido com 8 planetas, descoberto por inteligência artificial.
            </p>
            <div className="pointer-events-auto mt-8 flex flex-wrap gap-3 justify-center">
              <Link to="/sistema-solar" className="rounded-full bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90 transition shadow-glow">
                Iniciar exploração
              </Link>
              <Link to="/ao-vivo" className="rounded-full border border-rose-400/50 bg-rose-500/10 px-6 py-2.5 text-sm font-medium hover:bg-rose-500/20 transition flex items-center gap-2">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-70 animate-ping" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-rose-500" />
                </span>
                ISS ao vivo
              </Link>
              <Link to="/comparacao" className="rounded-full border border-border bg-secondary/40 px-6 py-2.5 text-sm font-medium hover:bg-secondary/70 transition">
                Comparar sistemas
              </Link>
            </div>
          </div>
        )}

        {showHint && !focused && (
          <div className="pointer-events-none absolute left-1/2 top-1/2 z-10 -translate-x-1/2 translate-y-12 animate-fade-in">
            <div className="glass rounded-xl px-3 py-2 text-[11px] font-mono uppercase tracking-widest text-primary shadow-glow whitespace-nowrap">
              ↑ clique no planeta em órbita para explorar
              <div className="absolute -top-1 left-1/2 h-2 w-2 -translate-x-1/2 rotate-45 bg-primary/80" />
            </div>
          </div>
        )}

        <PlanetPanel planet={planet} onClose={() => setFocused(null)} />
      </section>

      <InterstellarTrailer />

      <section className="relative px-6 py-20 max-w-7xl mx-auto">
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <ShootingStars />
        </div>
        <div className="text-center mb-12 animate-fade-up">
          <span className="font-mono text-xs uppercase tracking-[0.4em] text-primary/80">
            Navegue o universo
          </span>
          <h2 className="mt-3 text-3xl md:text-5xl font-bold text-gradient">
            Por onde quer começar?
          </h2>
        </div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {QUICK_NAV.map((item, i) => (
            <Link
              key={item.to}
              to={item.to as any}
              className="group relative overflow-hidden rounded-2xl glass p-4 transition hover:scale-[1.03] hover:shadow-glow animate-fade-up"
              style={{ animationDelay: `${i * 70}ms` }}
            >
              <div className="relative h-32 w-full mb-4">
                <Preview kind={item.preview} />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-1">{item.label}</h3>
              <p className="text-sm text-muted-foreground">{item.desc}</p>
              <div className="mt-3 font-mono text-[11px] uppercase tracking-widest text-primary/80 group-hover:text-primary transition">
                explorar →
              </div>
            </Link>
          ))}
        </div>
      </section>
    </main>
  );
}
