import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { SolarScene } from "@/components/SolarScene";
import { ShootingStars } from "@/components/ShootingStars";
import { SOLAR } from "@/lib/planets";
import { ScrollProgress } from "@/components/ScrollProgress";

export const Route = createFileRoute("/sistema-solar")({
  head: () => ({
    meta: [
      { title: "Sistema Solar — NexStationX" },
      {
        name: "description",
        content: "Tour narrativo: role a página para viajar pela Terra, Marte e Júpiter em 3D.",
      },
      { property: "og:title", content: "Sistema Solar — NexStationX" },
      {
        property: "og:description",
        content: "Scroll storytelling com órbitas em proporção real e câmera cinematográfica.",
      },
    ],
  }),
  component: SolarPage,
});

type Stop = { id: string | null; title: string; subtitle: string; body: string };

const STOPS: Stop[] = [
  {
    id: null,
    title: "Sistema Solar",
    subtitle: "Seção 01 · Tour Narrativo",
    body: "Role a página para viajar pelos planetas. A câmera segue automaticamente cada parada — você também pode clicar em qualquer planeta na cena.",
  },
  ...SOLAR.map((p) => ({
    id: p.id,
    title: p.name,
    subtitle: `${p.type === "rochoso" ? "Planeta Rochoso" : "Gigante Gasoso"} · ${p.distanceAU} UA`,
    body: p.description,
  })),
  {
    id: null,
    title: "Próxima Parada: Kepler-90",
    subtitle: "Seção 02",
    body: "Continue rolando para conhecer o sistema gêmeo descoberto pela NASA com inteligência artificial.",
  },
];

function SolarPage() {
  const [focused, setFocused] = useState<string | null>(null);
  const [activeIdx, setActiveIdx] = useState(0);
  const sectionRefs = useRef<(HTMLElement | null)[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio > 0.5) {
            const idx = Number(entry.target.getAttribute("data-idx"));
            setActiveIdx(idx);
            setFocused(STOPS[idx].id);
          }
        });
      },
      { threshold: [0, 0.5, 1] }
    );
    sectionRefs.current.forEach((el) => el && observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <main className="relative w-full pt-16">
      <ScrollProgress label={`${STOPS[activeIdx]?.title ?? ""} — ${activeIdx + 1} de ${STOPS.length}`} />
      {/* Cena 3D fixa no fundo */}
      <div className="fixed inset-0 top-16 -z-0">
        <SolarScene
          planets={SOLAR}
          focusedId={focused}
          onSelectPlanet={setFocused}
          starColor={0xffcc66}
        />
      </div>

      {/* Indicador de progresso lateral */}
      <div className="fixed right-6 top-1/2 z-20 -translate-y-1/2 hidden md:flex flex-col gap-3">
        {STOPS.map((s, i) => (
          <button
            key={i}
            onClick={() => sectionRefs.current[i]?.scrollIntoView({ behavior: "smooth" })}
            className={`h-2 rounded-full transition-all ${
              i === activeIdx ? "w-8 bg-primary shadow-glow" : "w-2 bg-foreground/30 hover:bg-foreground/60"
            }`}
            aria-label={`Ir para ${s.title}`}
          />
        ))}
      </div>

      {/* Seções narrativas — cada uma fixa o foco da câmera enquanto está visível */}
      {STOPS.map((stop, i) => (
        <section
          key={i}
          ref={(el) => {
            sectionRefs.current[i] = el;
          }}
          data-idx={i}
          className="relative h-screen w-full snap-start"
        >
          <div
            className={`absolute inset-y-0 z-10 flex w-full max-w-xl items-center p-6 md:p-12 ${
              i % 2 === 0 ? "left-0" : "right-0"
            }`}
          >
            <div
              className={`relative overflow-hidden rounded-2xl glass shadow-card p-8 transition-all duration-700 ${
                i === activeIdx ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
            >
              <ShootingStars />
              <div className="relative">
                <span className="font-mono text-xs uppercase tracking-[0.3em] text-primary/80">
                  {stop.subtitle}
                </span>
                <h1 className="mt-2 text-5xl font-bold text-gradient glow-text">{stop.title}</h1>
                <p className="mt-4 text-base text-foreground/90 leading-relaxed">{stop.body}</p>
                {stop.id && <PlanetMeta id={stop.id} />}
              </div>
            </div>
          </div>
        </section>
      ))}

      {/* Hint de scroll */}
      {activeIdx === 0 && (
        <div className="fixed bottom-8 left-1/2 z-20 -translate-x-1/2 animate-fade-in">
          <div className="flex flex-col items-center gap-2 text-muted-foreground">
            <span className="font-mono text-[10px] uppercase tracking-[0.3em]">Role para explorar</span>
            <div className="h-10 w-6 rounded-full border-2 border-primary/40 p-1">
              <div className="h-2 w-1 mx-auto rounded-full bg-primary animate-float" />
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

function PlanetMeta({ id }: { id: string }) {
  const p = SOLAR.find((x) => x.id === id);
  if (!p) return null;
  return (
    <div className="mt-6 grid grid-cols-2 gap-3 text-sm">
      <Stat label="Raio" value={`${p.radiusKm.toLocaleString()} km`} />
      <Stat label="Período" value={`${p.periodDays} dias`} />
      <Stat label="Temperatura" value={p.tempC} className="col-span-2" />
      <div className="col-span-2 mt-2 rounded-xl border border-primary/20 bg-primary/5 p-3">
        <div className="font-mono text-[10px] uppercase tracking-widest text-primary mb-1">
          Curiosidade
        </div>
        <p className="text-sm text-foreground/90">{p.curiosity}</p>
      </div>
    </div>
  );
}

function Stat({ label, value, className = "" }: { label: string; value: string; className?: string }) {
  return (
    <div className={`rounded-lg border border-border bg-secondary/30 px-3 py-2 ${className}`}>
      <div className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-0.5 text-sm font-medium text-foreground">{value}</div>
    </div>
  );
}
