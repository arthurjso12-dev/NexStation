import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ShootingStars } from "@/components/ShootingStars";

export const Route = createFileRoute("/ao-vivo")({
  head: () => ({
    meta: [
      { title: "Câmera ao Vivo da ISS — NexStationX" },
      {
        name: "description",
        content:
          "Acompanhe a Estação Espacial Internacional em tempo real, direto da órbita terrestre.",
      },
      { property: "og:title", content: "Câmera ao Vivo da ISS — NexStationX" },
      {
        property: "og:description",
        content: "Vista da Terra a 408 km de altitude, atualizada em tempo real pela NASA.",
      },
    ],
  }),
  component: AoVivoPage,
});

const FEEDS = [
  {
    id: "isslivenow",
    label: "ISS Live Now",
    url: "https://isslivenow.com/",
    description: "Câmera externa da ISS apontada para a Terra. Vista a 408 km de altitude.",
  },
  {
    id: "nasa-iss",
    label: "ISS HD Earth View",
    url: "https://www.youtube.com/embed/H999s0P1Er0?autoplay=1&mute=1",
    description: "Transmissão HD ao vivo da Terra vista da Estação Espacial Internacional.",
  },
  {
    id: "nasa-tv",
    label: "NASA TV Public",
    url: "https://www.youtube.com/embed/DIgkvm2nmHc?autoplay=1&mute=1",
    description: "Canal oficial NASA TV com missões, lançamentos e ciência ao vivo.",
  },
  {
    id: "spacex",
    label: "SpaceX Live",
    url: "https://www.youtube.com/embed/mhJRzQsLZGg?autoplay=1&mute=1",
    description: "Transmissões e lançamentos da SpaceX em tempo real.",
  },
];

function AoVivoPage() {
  const [feedId, setFeedId] = useState(FEEDS[0].id);
  const feed = FEEDS.find((f) => f.id === feedId)!;

  return (
    <main className="relative min-h-screen pt-24 pb-20">
      <div className="fixed inset-0 -z-10">
        <ShootingStars />
      </div>

      <header className="relative px-6 max-w-6xl mx-auto text-center pb-8 animate-fade-up">
        <span className="font-mono text-xs uppercase tracking-[0.4em] text-primary/80">
          Transmissão · Tempo Real
        </span>
        <h1 className="mt-4 text-5xl md:text-6xl font-bold text-gradient glow-text">
          Câmera ao Vivo
        </h1>
        <p className="mt-4 max-w-2xl mx-auto text-sm md:text-base text-muted-foreground">
          A Estação Espacial Internacional orbita a Terra a cerca de 28.000 km/h e completa uma
          volta a cada 90 minutos. Veja o que ela vê — agora.
        </p>

        {/* Status pill */}
        <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-rose-400/40 bg-rose-500/10 px-4 py-1.5">
          <span className="relative flex h-2.5 w-2.5">
            <span className="absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-70 animate-ping" />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-rose-500" />
          </span>
          <span className="font-mono text-[11px] uppercase tracking-widest text-rose-200">
            Ao vivo agora
          </span>
        </div>
      </header>

      {/* Feed switcher */}
      <div className="relative px-6 max-w-6xl mx-auto mb-4 flex flex-wrap gap-2 justify-center">
        {FEEDS.map((f) => (
          <button
            key={f.id}
            onClick={() => setFeedId(f.id)}
            className={`rounded-full px-4 py-2 text-xs font-mono uppercase tracking-widest transition ${
              feedId === f.id
                ? "bg-primary text-primary-foreground shadow-glow"
                : "glass text-muted-foreground hover:text-foreground"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Player */}
      <section className="relative px-6 max-w-6xl mx-auto">
        <div className="relative overflow-hidden rounded-2xl border border-border shadow-card glass">
          <div className="aspect-video w-full bg-black">
            <iframe
              key={feed.id}
              src={feed.url}
              title={feed.label}
              className="h-full w-full"
              allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
              referrerPolicy="no-referrer"
              allowFullScreen
            />
          </div>
          <div className="border-t border-border/40 bg-card px-6 py-4 flex items-start justify-between gap-4">
            <div>
              <h2 className="text-sm font-semibold text-foreground">{feed.label}</h2>
              <p className="text-xs text-muted-foreground mt-1">{feed.description}</p>
            </div>
            <a
              href={feed.url}
              target="_blank"
              rel="noreferrer"
              className="shrink-0 rounded-full border border-border bg-secondary/40 px-3 py-1.5 text-[11px] font-mono uppercase tracking-widest hover:bg-secondary/70 transition"
            >
              abrir ↗
            </a>
          </div>
        </div>

        {/* Info cards */}
        <div className="mt-8 grid gap-4 sm:grid-cols-3">
          {[
            { k: "Altitude", v: "408 km", d: "Órbita baixa terrestre" },
            { k: "Velocidade", v: "27.600 km/h", d: "16 voltas por dia" },
            { k: "Tripulação", v: "7 astronautas", d: "Rotação a cada 6 meses" },
          ].map((s) => (
            <div key={s.k} className="rounded-2xl glass p-5 text-center">
              <div className="font-mono text-[10px] uppercase tracking-widest text-primary/80">
                {s.k}
              </div>
              <div className="mt-1 text-2xl font-bold text-gradient">{s.v}</div>
              <div className="text-xs text-muted-foreground mt-1">{s.d}</div>
            </div>
          ))}
        </div>

        {/* Notice */}
        <p className="mt-6 text-center text-[11px] font-mono uppercase tracking-widest text-muted-foreground">
          Se a transmissão estiver escura, a ISS está no lado noturno da Terra.
          {" · "}
          Se aparecer um aviso azul, a câmera está sendo trocada.
        </p>
      </section>

    </main>
  );
}
