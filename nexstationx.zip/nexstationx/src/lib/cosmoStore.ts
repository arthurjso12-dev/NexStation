// Persistência local para Cosmo: planetas visitados, selos, contagem de visitas
export type BadgeId =
  | "first_visit"
  | "all_solar"
  | "iss_watch"
  | "quiz_master"
  | "easter_sun"
  | "easter_k"
  | "asteroid_pilot";

const KEY = "nexstationx.cosmo.v1";

type CosmoState = {
  visits: number;
  visited: string[];
  badges: BadgeId[];
  quizScore: number;
  highScore: number;
  lastSeen: number;
};

const DEFAULT: CosmoState = {
  visits: 0,
  visited: [],
  badges: [],
  quizScore: 0,
  highScore: 0,
  lastSeen: 0,
};

export function loadCosmo(): CosmoState {
  if (typeof window === "undefined") return DEFAULT;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT;
    return { ...DEFAULT, ...JSON.parse(raw) };
  } catch {
    return DEFAULT;
  }
}

export function saveCosmo(s: CosmoState) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
    window.dispatchEvent(new CustomEvent("cosmo:update"));
  } catch {
    /* no-op */
  }
}

export function visitPlanet(id: string) {
  const s = loadCosmo();
  if (!s.visited.includes(id)) {
    s.visited.push(id);
  }
  saveCosmo(s);
}

export function awardBadge(id: BadgeId) {
  const s = loadCosmo();
  if (!s.badges.includes(id)) {
    s.badges.push(id);
    saveCosmo(s);
    if (typeof window !== "undefined") {
      window.dispatchEvent(new CustomEvent("cosmo:badge", { detail: id }));
    }
  }
}

export function bumpVisit() {
  const s = loadCosmo();
  s.visits += 1;
  s.lastSeen = Date.now();
  if (s.visits === 1) {
    s.badges.push("first_visit");
  }
  saveCosmo(s);
}

export function setQuizScore(delta: number) {
  const s = loadCosmo();
  s.quizScore += delta;
  saveCosmo(s);
}

export function setHighScore(score: number) {
  const s = loadCosmo();
  if (score > s.highScore) {
    s.highScore = score;
    saveCosmo(s);
  }
}

export const ALL_BADGES: { id: BadgeId; label: string; emoji: string; desc: string }[] = [
  { id: "first_visit", label: "Primeiro contato", emoji: "🛰️", desc: "Visitou o NexStationX" },
  { id: "all_solar", label: "Tour Completo", emoji: "🪐", desc: "Visitou todos os planetas do Sistema Solar" },
  { id: "iss_watch", label: "Observador ISS", emoji: "📡", desc: "Assistiu à ISS por 1 min" },
  { id: "quiz_master", label: "Mestre do Quiz", emoji: "🧠", desc: "Pontuou 5+ no quiz" },
  { id: "easter_sun", label: "Erupção Solar", emoji: "☀️", desc: "Clicou 5× no Sol" },
  { id: "easter_k", label: "Kosmopedia", emoji: "🔑", desc: "Descobriu o atalho secreto" },
  { id: "asteroid_pilot", label: "Piloto Asteroide", emoji: "🚀", desc: "Sobreviveu 30s no campo de asteroides" },
];
