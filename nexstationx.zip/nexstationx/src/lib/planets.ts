// Planet data — radii in km, distances in AU, periods in Earth days
// Real proportional speeds via orbital period; visual scale is compressed for display.

export type Planet = {
  id: string;
  name: string;
  system: "solar" | "kepler90";
  color: string; // hex for three.js
  radiusKm: number;
  distanceAU: number;
  periodDays: number;
  type: "rochoso" | "gasoso";
  tempC: string;
  composition: string;
  description: string;
  curiosity: string;
  funFacts: string[];
  experiences: string[];
};

// Sistema Solar — todos os 8 planetas
export const SOLAR: Planet[] = [
  {
    id: "mercury",
    name: "Mercúrio",
    system: "solar",
    color: "#a8a29e",
    radiusKm: 2440,
    distanceAU: 0.387,
    periodDays: 88,
    type: "rochoso",
    tempC: "-173 a 427 °C",
    composition: "Núcleo de ferro massivo, manto rochoso fino, sem atmosfera",
    description:
      "O menor e mais interno planeta do Sistema Solar. Possui a maior variação térmica conhecida — quase 600 °C entre dia e noite.",
    curiosity: "Um ano em Mercúrio dura 88 dias, mas um dia solar dura 176 dias terrestres.",
    funFacts: [
      "Núcleo ocupa 75% do raio do planeta",
      "Sem atmosfera — superfície coberta por crateras",
      "Velocidade orbital de 47 km/s — a mais rápida do Sistema Solar",
    ],
    experiences: ["Veja o Sol parecendo 3× maior no céu"],
  },
  {
    id: "venus",
    name: "Vênus",
    system: "solar",
    color: "#eab308",
    radiusKm: 6052,
    distanceAU: 0.723,
    periodDays: 225,
    type: "rochoso",
    tempC: "~465 °C (constante)",
    composition: "Atmosfera densa de CO₂, nuvens de ácido sulfúrico, superfície vulcânica",
    description:
      "O planeta mais quente do Sistema Solar — efeito estufa descontrolado. A pressão na superfície equivale a 900 metros de profundidade no oceano terrestre.",
    curiosity: "Vênus gira ao contrário: o Sol nasce no oeste e se põe no leste.",
    funFacts: [
      "Mais brilhante objeto natural após Sol e Lua",
      "Um dia em Vênus é mais longo que seu ano",
      "Chove ácido sulfúrico em altitudes médias",
    ],
    experiences: ["Mergulhe pelas nuvens douradas de ácido sulfúrico"],
  },
  {
    id: "earth",
    name: "Terra",
    system: "solar",
    color: "#3b82f6",
    radiusKm: 6371,
    distanceAU: 1.0,
    periodDays: 365.25,
    type: "rochoso",
    tempC: "-88 a 58 °C",
    composition: "Silicatos, ferro, água líquida, atmosfera de N₂/O₂",
    description:
      "O único mundo conhecido a abrigar vida. Possui placas tectônicas ativas, oceanos líquidos e um campo magnético gerado pelo núcleo de ferro líquido que protege a superfície da radiação solar.",
    curiosity:
      "A Terra não é uma esfera perfeita — é um esferóide oblato achatado nos polos devido à sua rotação.",
    funFacts: [
      "71% da superfície é coberta por água líquida",
      "Gira a 1.670 km/h no equador",
      "A atmosfera contém 21% de oxigênio livre — uma anomalia química",
    ],
    experiences: [
      "Veja o terminador (linha entre dia e noite) girar em tempo real",
      "Observe as nuvens girando sobre os oceanos",
    ],
  },
  {
    id: "mars",
    name: "Marte",
    system: "solar",
    color: "#ef4444",
    radiusKm: 3389,
    distanceAU: 1.524,
    periodDays: 687,
    type: "rochoso",
    tempC: "-153 a 20 °C",
    composition: "Óxido de ferro (rocha avermelhada), atmosfera fina de CO₂",
    description:
      "O planeta vermelho abriga o maior vulcão do Sistema Solar (Monte Olimpo) e o cânion Valles Marineris, com mais de 4.000 km de extensão.",
    curiosity: "Um dia em Marte dura 24h37min — quase idêntico ao da Terra.",
    funFacts: [
      "Monte Olimpo tem 22 km de altura — quase 3× o Everest",
      "Possui duas pequenas luas: Fobos e Deimos",
      "Já houve água líquida em sua superfície há bilhões de anos",
    ],
    experiences: [
      "Sobrevoe o cânion Valles Marineris (4.000 km de extensão)",
      "Veja a poeira vermelha que dá a cor característica",
    ],
  },
  {
    id: "jupiter",
    name: "Júpiter",
    system: "solar",
    color: "#f59e0b",
    radiusKm: 69911,
    distanceAU: 5.203,
    periodDays: 4333,
    type: "gasoso",
    tempC: "-145 °C (topo das nuvens)",
    composition: "Hidrogênio, hélio, metano, amônia",
    description:
      "Gigante gasoso com massa 2,5 vezes maior que todos os outros planetas somados. A Grande Mancha Vermelha é uma tempestade ativa há mais de 350 anos.",
    curiosity:
      "Júpiter possui pelo menos 95 luas conhecidas, incluindo Europa, candidata à existência de oceano subterrâneo.",
    funFacts: [
      "A Grande Mancha Vermelha caberia 2 Terras dentro",
      "Gira tão rápido que um dia dura apenas 9h55min",
      "Funciona como 'aspirador' protegendo planetas internos de cometas",
    ],
    experiences: [
      "Mergulhe pelas bandas atmosféricas em rotação",
      "Observe o tênue sistema de anéis descoberto pela Voyager",
    ],
  },
  {
    id: "saturn",
    name: "Saturno",
    system: "solar",
    color: "#fbbf24",
    radiusKm: 58232,
    distanceAU: 9.537,
    periodDays: 10759,
    type: "gasoso",
    tempC: "-178 °C (topo das nuvens)",
    composition: "Hidrogênio, hélio — densidade menor que a da água",
    description:
      "O senhor dos anéis. Seu sistema de anéis se estende por 282.000 km mas tem apenas dezenas de metros de espessura. Composto principalmente por gelo e poeira.",
    curiosity: "Saturno é tão pouco denso que flutuaria em um oceano grande o suficiente.",
    funFacts: [
      "Possui 146 luas confirmadas — incluindo Titã, com lagos de metano",
      "Hexágono no polo norte: tempestade de 30.000 km de lado",
      "Anéis podem desaparecer em ~100 milhões de anos",
    ],
    experiences: ["Sobrevoe os anéis de gelo de perto"],
  },
  {
    id: "uranus",
    name: "Urano",
    system: "solar",
    color: "#22d3ee",
    radiusKm: 25362,
    distanceAU: 19.191,
    periodDays: 30687,
    type: "gasoso",
    tempC: "-224 °C (mais frio do Sistema Solar)",
    composition: "Gelos de água, metano e amônia sobre núcleo rochoso",
    description:
      "O gigante gelado deitado de lado — seu eixo está inclinado 98°, fazendo com que cada polo passe 42 anos em escuridão total. O metano lhe dá a cor azul-ciano.",
    curiosity: "Urano gira de lado — possivelmente devido a uma colisão antiga com um corpo do tamanho da Terra.",
    funFacts: [
      "Polos recebem mais energia solar que o equador",
      "Possui 13 anéis tênues e escuros",
      "Visitado apenas uma vez: Voyager 2 em 1986",
    ],
    experiences: ["Veja o eixo deitado e o sistema de anéis verticais"],
  },
  {
    id: "neptune",
    name: "Netuno",
    system: "solar",
    color: "#1d4ed8",
    radiusKm: 24622,
    distanceAU: 30.069,
    periodDays: 60190,
    type: "gasoso",
    tempC: "-218 °C (topo das nuvens)",
    composition: "Hidrogênio, hélio, metano — núcleo rochoso e gelado",
    description:
      "O planeta mais distante. Possui os ventos mais violentos do Sistema Solar — atingindo 2.100 km/h, mais rápidos que a velocidade do som na Terra.",
    curiosity: "Netuno foi o primeiro planeta descoberto por matemática, antes de ser observado em 1846.",
    funFacts: [
      "Um ano em Netuno dura 165 anos terrestres",
      "Tritão, sua maior lua, orbita ao contrário — provavelmente capturada",
      "Pode chover diamantes no seu interior",
    ],
    experiences: ["Sinta os ventos supersônicos da Grande Mancha Escura"],
  },
];

// Kepler-90 — todos os 8 exoplanetas confirmados
export const KEPLER: Planet[] = [
  {
    id: "k90b",
    name: "Kepler-90b",
    system: "kepler90",
    color: "#06b6d4",
    radiusKm: 7634,
    distanceAU: 0.074,
    periodDays: 7.0,
    type: "rochoso",
    tempC: "~436 °C estimada",
    composition: "Super-Terra rochosa, possivelmente com atmosfera densa",
    description:
      "Planeta mais interno do sistema Kepler-90, com órbita ultra-rápida de apenas 7 dias. Sua proximidade da estrela hospedeira o torna extremamente quente.",
    curiosity: "Um ano em Kepler-90b é mais curto que uma semana terrestre.",
    funFacts: [
      "Orbita 13× mais perto da estrela do que Mercúrio do Sol",
      "Provavelmente possui rotação sincronizada (um lado eternamente diurno)",
      "Detectado pelo método de trânsito do Kepler",
    ],
    experiences: ["Veja a estrela hospedeira preencher metade do céu"],
  },
  {
    id: "k90c",
    name: "Kepler-90c",
    system: "kepler90",
    color: "#0ea5e9",
    radiusKm: 7187,
    distanceAU: 0.089,
    periodDays: 8.72,
    type: "rochoso",
    tempC: "~380 °C estimada",
    composition: "Super-Terra rochosa, superfície escaldante",
    description:
      "Segundo planeta do sistema. Pouco maior que a Terra, orbita extremamente próximo da estrela e tem temperaturas hostis para a vida como conhecemos.",
    curiosity: "Tem raio 1,18× o da Terra — quase um irmão de tamanho.",
    funFacts: [
      "Período orbital de menos de 9 dias",
      "Possivelmente travado por maré",
      "Detectado em 2014 pela missão Kepler",
    ],
    experiences: ["Compare seu tamanho com a Terra"],
  },
  {
    id: "k90i",
    name: "Kepler-90i",
    system: "kepler90",
    color: "#22d3ee",
    radiusKm: 7570,
    distanceAU: 0.2,
    periodDays: 14.45,
    type: "rochoso",
    tempC: "~436 °C estimada",
    composition: "Super-Terra rochosa, superfície ardente",
    description:
      "Descoberto em 2017 pela NASA com auxílio de inteligência artificial do Google, Kepler-90i tornou Kepler-90 o primeiro sistema conhecido com 8 planetas — empatando com o nosso.",
    curiosity:
      "Foi o primeiro exoplaneta descoberto por uma rede neural treinada com dados do telescópio Kepler.",
    funFacts: [
      "Descoberto por Inteligência Artificial em 2017",
      "Tornou Kepler-90 o 1º sistema conhecido com 8 planetas",
      "Treinamento da rede neural usou 15.000 sinais do Kepler",
    ],
    experiences: ["Reviva a descoberta histórica via timeline"],
  },
  {
    id: "k90d",
    name: "Kepler-90d",
    system: "kepler90",
    color: "#14b8a6",
    radiusKm: 18800,
    distanceAU: 0.32,
    periodDays: 59.74,
    type: "rochoso",
    tempC: "~200 °C estimada",
    composition: "Mini-Netuno ou super-Terra com envoltório gasoso",
    description:
      "Planeta intermediário com raio quase 3× o da Terra. Provavelmente uma transição entre rochoso e gasoso.",
    curiosity: "Faz parte da zona de planetas 'sub-Netunos' — comuns em outros sistemas, raros no nosso.",
    funFacts: [
      "Raio 2,9× o da Terra",
      "Densidade menor que a Terra — provável envoltório de hidrogênio",
      "Período orbital de ~60 dias",
    ],
    experiences: ["Imagine um mundo entre Terra e Netuno"],
  },
  {
    id: "k90e",
    name: "Kepler-90e",
    system: "kepler90",
    color: "#8b5cf6",
    radiusKm: 17600,
    distanceAU: 0.42,
    periodDays: 91.94,
    type: "rochoso",
    tempC: "~150 °C estimada",
    composition: "Mini-Netuno, atmosfera densa",
    description:
      "Quinto planeta do sistema. Raio cerca de 2,7× o da Terra. Orbita na zona temperada interna do sistema Kepler-90.",
    curiosity: "Período de 92 dias — semelhante ao de Mercúrio em torno do Sol.",
    funFacts: [
      "Provavelmente possui atmosfera espessa",
      "Detectado por trânsitos múltiplos pelo Kepler",
      "Raio 2,67× o da Terra",
    ],
    experiences: ["Compare com Mercúrio na visão orbital"],
  },
  {
    id: "k90f",
    name: "Kepler-90f",
    system: "kepler90",
    color: "#a855f7",
    radiusKm: 18000,
    distanceAU: 0.48,
    periodDays: 124.91,
    type: "rochoso",
    tempC: "~100 °C estimada",
    composition: "Sub-Netuno com possível envoltório de hidrogênio",
    description:
      "Sexto planeta do sistema. Tamanho similar ao Kepler-90e, mas mais distante da estrela. Possível candidato a estudos atmosféricos pelo James Webb.",
    curiosity: "Posição ressonante com os planetas vizinhos — característica de sistemas estáveis.",
    funFacts: [
      "Raio 2,89× o da Terra",
      "Período de ~125 dias",
      "Pode ter ressonância orbital com Kepler-90e",
    ],
    experiences: ["Observe a dança ressonante com seus vizinhos"],
  },
  {
    id: "k90g",
    name: "Kepler-90g",
    system: "kepler90",
    color: "#c084fc",
    radiusKm: 50000,
    distanceAU: 0.71,
    periodDays: 210.6,
    type: "gasoso",
    tempC: "~-23 °C estimada",
    composition: "Mini-Netuno, envoltório de hidrogênio e hélio",
    description:
      "Planeta gigante gasoso com tamanho próximo ao de Saturno. Orbita na zona intermediária do sistema Kepler-90.",
    curiosity: "É um dos maiores planetas conhecidos do sistema, com raio ~8× o da Terra.",
    funFacts: [
      "Massa estimada similar à de Júpiter",
      "Pode possuir luas grandes ainda não detectadas",
      "Orbita na zona temperada do sistema",
    ],
    experiences: ["Compare seu tamanho com Júpiter no modo comparação"],
  },
  {
    id: "k90h",
    name: "Kepler-90h",
    system: "kepler90",
    color: "#e879f9",
    radiusKm: 75000,
    distanceAU: 1.01,
    periodDays: 331.6,
    type: "gasoso",
    tempC: "~-10 °C estimada",
    composition: "Gigante gasoso joviano, hidrogênio e hélio",
    description:
      "O planeta mais externo conhecido do sistema. Tamanho semelhante a Júpiter e órbita próxima a 1 UA — quase como a Terra ao redor do Sol.",
    curiosity: "Orbita a uma distância similar à da Terra ao Sol, mas é um gigante gasoso.",
    funFacts: [
      "Raio 11,3× o da Terra — quase igual a Júpiter",
      "Período orbital de ~332 dias — quase um ano terrestre",
      "Marca o limite externo conhecido do sistema",
    ],
    experiences: ["Veja o gigante na borda do sistema"],
  },
];

export const ALL_PLANETS = [...SOLAR, ...KEPLER];
