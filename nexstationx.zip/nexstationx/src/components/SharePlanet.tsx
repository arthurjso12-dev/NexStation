import { useState } from "react";
import { Share2, Check } from "lucide-react";
import type { Planet } from "@/lib/planets";

export function SharePlanet({ planet }: { planet: Planet }) {
  const [copied, setCopied] = useState(false);

  const handleShare = async () => {
    const url = typeof window !== "undefined" ? window.location.href : "";
    const text = `🌌 ${planet.name} — ${planet.curiosity}\n\nDescubra mais no NexStationX:`;
    const data = { title: `${planet.name} · NexStationX`, text, url };
    try {
      if (navigator.share && navigator.canShare?.(data)) {
        await navigator.share(data);
        return;
      }
    } catch {
      /* fallback */
    }
    try {
      await navigator.clipboard.writeText(`${text} ${url}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      /* ignore */
    }
  };

  return (
    <button
      onClick={handleShare}
      className="mt-4 w-full inline-flex items-center justify-center gap-2 rounded-full bg-primary/15 hover:bg-primary/25 px-4 py-2 text-xs font-medium text-primary transition"
    >
      {copied ? <Check className="h-3 w-3" /> : <Share2 className="h-3 w-3" />}
      {copied ? "Link copiado!" : `Compartilhar ${planet.name}`}
    </button>
  );
}
