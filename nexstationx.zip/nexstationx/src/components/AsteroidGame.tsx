import { useEffect, useRef, useState } from "react";
import { Play, RotateCcw } from "lucide-react";
import { awardBadge, setHighScore } from "@/lib/cosmoStore";

const FACTS = [
  "O cinturão de asteroides tem massa total menor que a da nossa Lua.",
  "Vesta é o asteroide mais brilhante visível a olho nu (em raras condições).",
  "Bennu tem chance de 1 em 1.750 de impactar a Terra entre 2178 e 2290.",
  "Cerca de 100 toneladas de poeira espacial caem na Terra todos os dias.",
];

export function AsteroidGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [running, setRunning] = useState(false);
  const [time, setTime] = useState(0);
  const [over, setOver] = useState(false);
  const [fact, setFact] = useState("");
  const stateRef = useRef({
    keys: { left: false, right: false, up: false, down: false },
    asteroids: [] as { x: number; y: number; r: number; vx: number; vy: number }[],
    ship: { x: 200, y: 200 },
    last: 0,
    start: 0,
  });

  useEffect(() => {
    const onKey = (e: KeyboardEvent, down: boolean) => {
      const k = e.key;
      const s = stateRef.current.keys;
      if (k === "ArrowLeft" || k === "a") s.left = down;
      if (k === "ArrowRight" || k === "d") s.right = down;
      if (k === "ArrowUp" || k === "w") s.up = down;
      if (k === "ArrowDown" || k === "s") s.down = down;
    };
    const dn = (e: KeyboardEvent) => onKey(e, true);
    const up = (e: KeyboardEvent) => onKey(e, false);
    window.addEventListener("keydown", dn);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", dn);
      window.removeEventListener("keyup", up);
    };
  }, []);

  useEffect(() => {
    if (!running) return;
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext("2d")!;
    const W = canvas.width;
    const H = canvas.height;
    const st = stateRef.current;
    st.ship = { x: W / 2, y: H - 50 };
    st.asteroids = [];
    st.start = performance.now();

    let raf = 0;
    const tick = (now: number) => {
      const dt = Math.min(0.05, (now - (st.last || now)) / 1000);
      st.last = now;
      const elapsed = (now - st.start) / 1000;
      setTime(elapsed);

      ctx.fillStyle = "rgba(5, 8, 25, 0.5)";
      ctx.fillRect(0, 0, W, H);

      // ship
      const sp = 220;
      if (st.keys.left) st.ship.x -= sp * dt;
      if (st.keys.right) st.ship.x += sp * dt;
      if (st.keys.up) st.ship.y -= sp * dt;
      if (st.keys.down) st.ship.y += sp * dt;
      st.ship.x = Math.max(15, Math.min(W - 15, st.ship.x));
      st.ship.y = Math.max(15, Math.min(H - 15, st.ship.y));

      // spawn
      if (Math.random() < 0.04 + Math.min(0.08, elapsed * 0.003)) {
        const r = 8 + Math.random() * 18;
        st.asteroids.push({
          x: Math.random() * W,
          y: -20,
          r,
          vx: (Math.random() - 0.5) * 60,
          vy: 80 + Math.random() * 90 + elapsed * 4,
        });
      }

      // update + draw asteroids
      ctx.fillStyle = "#b89878";
      st.asteroids = st.asteroids.filter((a) => {
        a.x += a.vx * dt;
        a.y += a.vy * dt;
        ctx.beginPath();
        ctx.arc(a.x, a.y, a.r, 0, Math.PI * 2);
        ctx.fill();
        // collision
        const dx = a.x - st.ship.x;
        const dy = a.y - st.ship.y;
        if (Math.hypot(dx, dy) < a.r + 10) {
          end();
        }
        return a.y < H + 30;
      });

      // ship draw
      ctx.fillStyle = "#66ccff";
      ctx.beginPath();
      ctx.moveTo(st.ship.x, st.ship.y - 12);
      ctx.lineTo(st.ship.x - 10, st.ship.y + 10);
      ctx.lineTo(st.ship.x + 10, st.ship.y + 10);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "#ff8866";
      ctx.fillRect(st.ship.x - 4, st.ship.y + 10, 8, 6);

      if (elapsed >= 30) {
        win();
        return;
      }
      raf = requestAnimationFrame(tick);
    };
    const end = () => {
      cancelAnimationFrame(raf);
      const elapsed = (performance.now() - st.start) / 1000;
      setHighScore(Math.floor(elapsed));
      setOver(true);
      setRunning(false);
      setFact(FACTS[Math.floor(Math.random() * FACTS.length)]);
    };
    const win = () => {
      cancelAnimationFrame(raf);
      setHighScore(30);
      awardBadge("asteroid_pilot");
      setOver(true);
      setRunning(false);
      setFact("Você completou os 30 segundos! " + FACTS[Math.floor(Math.random() * FACTS.length)]);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [running]);

  return (
    <div className="glass rounded-2xl p-4 shadow-card">
      <div className="flex items-center justify-between mb-3">
        <div>
          <div className="font-mono text-[10px] uppercase tracking-widest text-primary">Mini-jogo</div>
          <h3 className="text-lg font-bold">Pilote pelo cinturão</h3>
        </div>
        <div className="font-mono text-xs text-muted-foreground">
          {running ? `${time.toFixed(1)}s / 30s` : over ? `Score: ${time.toFixed(1)}s` : "30s desafio"}
        </div>
      </div>
      <div className="relative">
        <canvas
          ref={canvasRef}
          width={500}
          height={300}
          className="w-full rounded-lg border border-border bg-[#05081a]"
        />
        {!running && (
          <div className="absolute inset-0 flex items-center justify-center">
            <button
              onClick={() => {
                setOver(false);
                setTime(0);
                setRunning(true);
              }}
              className="rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground shadow-glow hover:opacity-90 inline-flex items-center gap-2"
            >
              {over ? <RotateCcw className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              {over ? "Tentar de novo" : "Iniciar"}
            </button>
          </div>
        )}
      </div>
      {over && fact && (
        <div className="mt-3 rounded-lg border border-primary/20 bg-primary/5 p-3 text-xs text-foreground/85 animate-fade-in">
          💡 {fact}
        </div>
      )}
      <div className="mt-2 font-mono text-[10px] text-muted-foreground">
        Setas / WASD para mover · evite os asteroides
      </div>
    </div>
  );
}
