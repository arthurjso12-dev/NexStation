import { useEffect, useState } from "react";
import { Sparkles, X } from "lucide-react";

type Event = { from: string; to: string; title: string; emoji: string };

const EVENTS: Event[] = [
  { from: "07-16", to: "07-24", title: "Aniversário do pouso na Lua (Apollo 11)", emoji: "🌕" },
  { from: "04-12", to: "04-12", title: "Dia Internacional dos Voos Espaciais Tripulados", emoji: "🚀" },
  { from: "04-16", to: "04-16", title: "Dia do Sistema Solar", emoji: "☀️" },
  { from: "10-04", to: "10-10", title: "Semana Mundial do Espaço", emoji: "🛰️" },
  { from: "12-21", to: "12-21", title: "Solstício — alinhamento da Terra com o Sol", emoji: "✨" },
];

function inRange(today: string, from: string, to: string) {
  return today >= from && today <= to;
}

export function SeasonalBanner() {
  const [closed, setClosed] = useState(false);
  const [evt, setEvt] = useState<Event | null>(null);

  useEffect(() => {
    const d = new Date();
    const today = `${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    const found = EVENTS.find((e) => inRange(today, e.from, e.to)) ?? EVENTS[0];
    setEvt(found);
  }, []);

  if (!evt || closed) return null;
  return (
    <div className="fixed bottom-4 left-1/2 z-30 -translate-x-1/2 glass rounded-full pl-4 pr-2 py-1.5 text-xs flex items-center gap-2 shadow-card animate-fade-in max-w-[90vw]">
      <Sparkles className="h-3 w-3 text-accent" />
      <span className="text-foreground/90 truncate">
        {evt.emoji} {evt.title}
      </span>
      <button
        onClick={() => setClosed(true)}
        className="ml-1 rounded-full p-1 text-muted-foreground hover:text-foreground"
        aria-label="Fechar"
      >
        <X className="h-3 w-3" />
      </button>
    </div>
  );
}
