import { Link, useLocation } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X } from "lucide-react";

type NavItem = { to: string; label: string };

// 5 itens principais visíveis
const NAV_ITEMS: NavItem[] = [
  { to: "/sistema-solar", label: "Solar" },
  { to: "/kepler-90", label: "Kepler-90" },
  { to: "/comparacao", label: "Comparar" },
  { to: "/exploracao", label: "Explorar" },
  { to: "/ao-vivo", label: "Ao Vivo" },
];

const EXTRA_ITEMS: NavItem[] = [
  { to: "/asteroides", label: "Asteroides" },
  { to: "/descobertas", label: "Descobertas" },
  { to: "/curiosidades", label: "Curiosidades" },
  { to: "/linha-do-tempo", label: "Linha do Tempo" },
  { to: "/futuro", label: "Futuro" },
];

export function Header() {
  const location = useLocation();
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass">
      <div className="mx-auto flex max-w-[1600px] items-center justify-between px-4 md:px-6 py-3">
        <Link to="/" className="flex items-center gap-2 group shrink-0" onClick={() => setOpen(false)}>
          <div className="relative h-8 w-8">
            <div className="absolute inset-0 rounded-full bg-primary animate-pulse-glow" />
            <div className="absolute inset-1 rounded-full bg-background" />
            <div className="absolute inset-2 rounded-full bg-gradient-to-br from-primary to-accent" />
          </div>
          <span className="font-mono text-sm tracking-widest text-foreground whitespace-nowrap">
            NEXSTATIONX
          </span>
        </Link>

        {/* Desktop nav — 8 sessões visíveis */}
        <nav className="hidden lg:flex items-center gap-0.5">
          {NAV_ITEMS.map((item) => {
            const active = location.pathname === item.to;
            return (
              <Link
                key={item.to}
                to={item.to as any}
                className={`relative px-2.5 py-2 text-[11px] font-medium tracking-wide uppercase transition-colors whitespace-nowrap ${
                  active
                    ? "text-primary"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {item.label}
                {active && (
                  <span className="absolute bottom-0.5 left-2.5 right-2.5 h-px bg-primary" />
                )}
              </Link>
            );
          })}
          {/* Extras dropdown */}
          <div className="relative group ml-1">
            <button className="px-2.5 py-2 text-[11px] font-medium tracking-wide uppercase text-muted-foreground hover:text-foreground">
              Mais ▾
            </button>
            <div className="invisible group-hover:visible absolute right-0 top-full mt-1 min-w-[160px] glass rounded-xl p-2 shadow-card">
              {EXTRA_ITEMS.map((item) => (
                <Link
                  key={item.to}
                  to={item.to as any}
                  className="block rounded-lg px-3 py-2 text-[11px] uppercase tracking-wide text-muted-foreground hover:bg-secondary/50 hover:text-foreground"
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </div>
        </nav>

        {/* Mobile toggle */}
        <button
          className="lg:hidden text-foreground"
          onClick={() => setOpen((o) => !o)}
          aria-label="Menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Mobile drawer */}
      {open && (
        <nav className="lg:hidden border-t border-border bg-background/95 px-6 py-4 animate-fade-in">
          <Link
            to="/"
            onClick={() => setOpen(false)}
            className="block py-2 text-sm uppercase tracking-wider text-muted-foreground hover:text-primary"
          >
            Início
          </Link>
          {[...NAV_ITEMS, ...EXTRA_ITEMS].map((item) => (
            <Link
              key={item.to}
              to={item.to as any}
              onClick={() => setOpen(false)}
              className={`block py-2 text-sm uppercase tracking-wider transition ${
                location.pathname === item.to ? "text-primary" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}
