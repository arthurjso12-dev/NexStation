import type { Planet } from "@/lib/planets";
import { ShootingStars } from "./ShootingStars";
import { PlanetQuiz } from "./PlanetQuiz";
import { SharePlanet } from "./SharePlanet";
import { X, Sparkles, Compass, RotateCcw } from "lucide-react";

type Props = {
  planet: Planet | null;
  onClose: () => void;
  mode?: "easy" | "radical";
};

export function PlanetPanel({ planet, onClose, mode = "easy" }: Props) {
  if (!planet) return null;
  const radical = mode === "radical";

  return (
    <aside className="pointer-events-none absolute inset-y-0 right-0 z-20 flex w-full md:w-[460px] items-stretch p-4 md:p-8 animate-fade-in">
      <div className="pointer-events-auto relative flex-1 overflow-hidden rounded-2xl glass shadow-card">
        <ShootingStars />
        <div className="relative h-full flex flex-col p-8 overflow-y-auto">
          <button
            onClick={onClose}
            className="absolute right-4 top-4 rounded-full p-2 text-muted-foreground hover:text-foreground hover:bg-secondary transition"
            aria-label="Fechar"
          >
            <X className="h-4 w-4" />
          </button>

          <div className="font-mono text-xs uppercase tracking-widest text-primary/70 flex items-center gap-2">
            {planet.system === "solar" ? "Sistema Solar" : "Kepler-90 · 2545 anos-luz"}
            <span
              className={`rounded-full px-2 py-0.5 text-[9px] ${
                radical ? "bg-accent/20 text-accent" : "bg-primary/15 text-primary"
              }`}
            >
              {radical ? "MODO RADICAL" : "MODO FÁCIL"}
            </span>
          </div>
          <h2 className="mt-2 text-4xl font-bold text-gradient glow-text">{planet.name}</h2>

          <div className="mt-6 grid grid-cols-2 gap-3 text-sm">
            <Stat label="Tipo" value={planet.type === "rochoso" ? "Rochoso" : "Gasoso"} />
            <Stat label="Raio" value={`${planet.radiusKm.toLocaleString()} km`} />
            <Stat label="Distância" value={`${planet.distanceAU} UA`} />
            <Stat label="Ano" value={`${planet.periodDays} dias`} />
            <Stat label="Temperatura" value={planet.tempC} className="col-span-2" />
          </div>

          <div className="mt-6">
            <h3 className="font-mono text-xs uppercase tracking-widest text-muted-foreground mb-2">
              Composição
            </h3>
            <p className="text-sm text-foreground/90 leading-relaxed">{planet.composition}</p>
          </div>

          <div className="mt-6">
            <h3 className="font-mono text-xs uppercase tracking-widest text-muted-foreground mb-2">
              Descrição
            </h3>
            <p className="text-sm text-foreground/90 leading-relaxed">{planet.description}</p>
          </div>

          <div className="mt-6 rounded-xl border border-primary/20 bg-primary/5 p-4">
            <h3 className="font-mono text-xs uppercase tracking-widest text-primary mb-2 flex items-center gap-2">
              <Sparkles className="h-3 w-3" /> Curiosidade
            </h3>
            <p className="text-sm text-foreground/90 leading-relaxed">{planet.curiosity}</p>
          </div>

          {/* Fatos rápidos — modo fácil */}
          {!radical && (
            <div className="mt-4 space-y-2">
              <h3 className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
                Fatos rápidos
              </h3>
              {planet.funFacts.map((f, i) => (
                <div
                  key={i}
                  className="flex gap-2 rounded-lg border border-border bg-secondary/20 p-3 text-sm animate-fade-up"
                  style={{ animationDelay: `${i * 80}ms` }}
                >
                  <span className="font-mono text-primary">0{i + 1}</span>
                  <span className="text-foreground/85">{f}</span>
                </div>
              ))}
            </div>
          )}

          {/* Experiências imersivas — modo radical */}
          {radical && (
            <div className="mt-4 space-y-2">
              <h3 className="font-mono text-xs uppercase tracking-widest text-accent flex items-center gap-2">
                <Compass className="h-3 w-3" /> Experiências imersivas
              </h3>
              {planet.experiences.map((e, i) => (
                <div
                  key={i}
                  className="rounded-lg border border-accent/30 bg-accent/5 p-3 text-sm animate-fade-up"
                  style={{ animationDelay: `${i * 80}ms` }}
                >
                  → {e}
                </div>
              ))}
            </div>
          )}

          <PlanetQuiz planetId={planet.id} />
          <SharePlanet planet={planet} />

          <button
            onClick={onClose}
            className="mt-3 w-full inline-flex items-center justify-center gap-2 rounded-full border border-border bg-secondary/40 hover:bg-secondary/70 px-4 py-2 text-xs font-mono uppercase tracking-widest text-muted-foreground"
          >
            <RotateCcw className="h-3 w-3" /> Resetar câmera
          </button>
        </div>
      </div>
    </aside>
  );
}

function Stat({ label, value, className = "" }: { label: string; value: string; className?: string }) {
  return (
    <div className={`rounded-lg border border-border bg-secondary/30 px-3 py-2 ${className}`}>
      <div className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-0.5 text-sm font-medium text-foreground">{value}</div>
    </div>
  );
}
