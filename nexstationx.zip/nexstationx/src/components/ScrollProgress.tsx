import { useEffect, useState } from "react";

export function ScrollProgress({ label }: { label?: string }) {
  const [pct, setPct] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      const total = h.scrollHeight - h.clientHeight;
      setPct(total > 0 ? (h.scrollTop / total) * 100 : 0);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="fixed left-0 right-0 top-16 z-40 pointer-events-none">
      <div className="h-0.5 bg-primary/10">
        <div
          className="h-full bg-gradient-to-r from-primary via-accent to-primary shadow-glow transition-[width] duration-150"
          style={{ width: `${pct}%` }}
        />
      </div>
      {label && (
        <div className="absolute right-3 top-1.5 glass rounded-full px-3 py-1 text-[10px] font-mono uppercase tracking-widest">
          <span className="text-primary">⬤</span> {label}
        </div>
      )}
    </div>
  );
}
