import { Link, useLocation } from "@tanstack/react-router";
import { ChevronRight, Home } from "lucide-react";

const LABELS: Record<string, string> = {
  "sistema-solar": "Sistema Solar",
  "kepler-90": "Kepler-90",
  comparacao: "Comparar",
  exploracao: "Explorar",
  asteroides: "Asteroides",
  descobertas: "Descobertas",
  curiosidades: "Curiosidades",
  "ao-vivo": "Ao Vivo",
  "linha-do-tempo": "Linha do Tempo",
  futuro: "Futuro",
};

export function Breadcrumbs() {
  const { pathname } = useLocation();
  if (pathname === "/") return null;
  const segs = pathname.split("/").filter(Boolean);
  return (
    <nav
      aria-label="Breadcrumbs"
      className="fixed left-4 top-[68px] z-30 hidden md:flex items-center gap-1 glass rounded-full px-3 py-1.5 text-[11px] font-mono uppercase tracking-widest text-muted-foreground"
    >
      <Link to="/" className="hover:text-primary flex items-center gap-1">
        <Home className="h-3 w-3" /> Início
      </Link>
      {segs.map((s, i) => {
        const path = "/" + segs.slice(0, i + 1).join("/");
        const isLast = i === segs.length - 1;
        return (
          <span key={s} className="flex items-center gap-1">
            <ChevronRight className="h-3 w-3 opacity-50" />
            {isLast ? (
              <span className="text-primary">{LABELS[s] ?? s}</span>
            ) : (
              <Link to={path as any} className="hover:text-primary">
                {LABELS[s] ?? s}
              </Link>
            )}
          </span>
        );
      })}
    </nav>
  );
}
