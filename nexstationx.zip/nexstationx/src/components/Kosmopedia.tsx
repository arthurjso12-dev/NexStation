import { useEffect, useState } from "react";
import { X, Shuffle } from "lucide-react";
import { awardBadge } from "@/lib/cosmoStore";

const FACTS = [
  "Existe um planeta de diamante chamado 55 Cancri e — sua superfície é coberta por carbono cristalino.",
  "Um dia em Vênus dura mais que um ano em Vênus (243 vs 225 dias terrestres).",
  "Há uma nuvem gigante de álcool no espaço — Sagittarius B2 contém bilhões de litros de etanol.",
  "Saturno flutuaria em água: sua densidade é menor que 1 g/cm³.",
  "Netuno tem ventos de até 2.100 km/h — os mais rápidos do Sistema Solar.",
  "A 'Voyager 1' é o objeto humano mais distante: já está no espaço interestelar.",
  "Existe um pulsar girando 716 vezes por segundo (PSR J1748-2446ad).",
  "O som não viaja no vácuo, mas as ondas gravitacionais sim — e elas curvam o espaço-tempo.",
  "A galáxia Andrômeda colidirá com a Via Láctea em ~4,5 bilhões de anos.",
  "Um ano no exoplaneta Kepler-78b dura apenas 8,5 horas.",
];

export function Kosmopedia() {
  const [open, setOpen] = useState(false);
  const [idx, setIdx] = useState(() => Math.floor(Math.random() * FACTS.length));

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target && (e.target as HTMLElement).tagName.match(/INPUT|TEXTAREA/)) return;
      if (e.key.toLowerCase() === "k") {
        setIdx(Math.floor(Math.random() * FACTS.length));
        setOpen(true);
        awardBadge("easter_k");
      }
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-[80] flex items-center justify-center bg-background/70 backdrop-blur-sm animate-fade-in p-4"
      onClick={() => setOpen(false)}
    >
      <div
        className="relative max-w-md w-full glass rounded-2xl p-6 shadow-glow"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={() => setOpen(false)}
          className="absolute right-3 top-3 text-muted-foreground hover:text-foreground"
        >
          <X className="h-4 w-4" />
        </button>
        <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-primary">
          Kosmopedia · Tecla [K]
        </div>
        <h2 className="mt-2 text-2xl font-bold text-gradient">Fato Cósmico Aleatório</h2>
        <p className="mt-4 text-sm leading-relaxed text-foreground/90">{FACTS[idx]}</p>
        <button
          onClick={() => setIdx((i) => (i + 1 + Math.floor(Math.random() * (FACTS.length - 1))) % FACTS.length)}
          className="mt-5 inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-xs font-medium text-primary-foreground hover:opacity-90 shadow-glow"
        >
          <Shuffle className="h-3 w-3" />
          Outro fato
        </button>
      </div>
    </div>
  );
}
