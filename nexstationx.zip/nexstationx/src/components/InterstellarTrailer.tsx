import { useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { EffectComposer, Bloom, Vignette, Noise, ChromaticAberration } from "@react-three/postprocessing";
import { motion, AnimatePresence } from "framer-motion";
import * as THREE from "three";

// Inspired-by, not copy: cinematic Interstellar-style hero sequence (Gargantua,
// wormhole, Endurance silhouette, dust planet) on a 24s loop.

const LOOP = 24; // seconds

function Gargantua({ tIn, tOut }: { tIn: number; tOut: number }) {
  const disk = useRef<THREE.Mesh>(null);
  const diskTop = useRef<THREE.Mesh>(null);
  const grp = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    const t = clock.elapsedTime % LOOP;
    const on = t >= tIn && t <= tOut;
    if (grp.current) {
      grp.current.visible = on;
      const local = (t - tIn) / (tOut - tIn);
      grp.current.position.z = -6 + Math.sin(local * Math.PI) * 1.2;
      grp.current.rotation.z = local * 0.2;
    }
    if (disk.current) disk.current.rotation.z += 0.004;
    if (diskTop.current) diskTop.current.rotation.z -= 0.003;
  });
  return (
    <group ref={grp}>
      {/* event horizon */}
      <mesh>
        <sphereGeometry args={[1.6, 64, 64]} />
        <meshBasicMaterial color={0x000000} />
      </mesh>
      {/* photon halo */}
      <mesh>
        <ringGeometry args={[1.62, 1.78, 256]} />
        <meshBasicMaterial color={0xffe1a8} side={THREE.DoubleSide} transparent opacity={1} blending={THREE.AdditiveBlending} />
      </mesh>
      {/* equatorial accretion disk */}
      <mesh ref={disk} rotation={[Math.PI / 2.4, 0, 0]}>
        <ringGeometry args={[1.9, 5.2, 256]} />
        <meshBasicMaterial color={0xffa64d} side={THREE.DoubleSide} transparent opacity={0.55} blending={THREE.AdditiveBlending} depthWrite={false} />
      </mesh>
      {/* lensed disk (over the top, the Interstellar "halo over the head") */}
      <mesh ref={diskTop} rotation={[0, 0, 0]}>
        <ringGeometry args={[1.8, 3.2, 256, 1, 0, Math.PI]} />
        <meshBasicMaterial color={0xffc878} side={THREE.DoubleSide} transparent opacity={0.5} blending={THREE.AdditiveBlending} depthWrite={false} />
      </mesh>
      <mesh rotation={[Math.PI, 0, 0]}>
        <ringGeometry args={[1.8, 3.2, 256, 1, 0, Math.PI]} />
        <meshBasicMaterial color={0xffc878} side={THREE.DoubleSide} transparent opacity={0.5} blending={THREE.AdditiveBlending} depthWrite={false} />
      </mesh>
    </group>
  );
}

function Wormhole({ tIn, tOut }: { tIn: number; tOut: number }) {
  const grp = useRef<THREE.Group>(null);
  const rings = useMemo(() => Array.from({ length: 18 }, (_, i) => i), []);
  useFrame(({ clock }) => {
    const t = clock.elapsedTime % LOOP;
    const on = t >= tIn && t <= tOut;
    if (grp.current) {
      grp.current.visible = on;
      grp.current.rotation.z = (t - tIn) * 0.4;
    }
  });
  return (
    <group ref={grp}>
      {rings.map((i) => {
        const z = -i * 1.2;
        const r = 0.8 + i * 0.3;
        return (
          <mesh key={i} position={[0, 0, z]} rotation={[Math.PI / 2, 0, i * 0.3]}>
            <torusGeometry args={[r, 0.015, 8, 64]} />
            <meshBasicMaterial color={i % 2 === 0 ? 0x88bbff : 0xffd166} transparent opacity={0.6} blending={THREE.AdditiveBlending} />
          </mesh>
        );
      })}
    </group>
  );
}

function DustPlanet({ tIn, tOut }: { tIn: number; tOut: number }) {
  const grp = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    const t = clock.elapsedTime % LOOP;
    const on = t >= tIn && t <= tOut;
    if (grp.current) {
      grp.current.visible = on;
      const p = (t - tIn) / (tOut - tIn);
      grp.current.position.set(-6 + p * 12, -1, -8 + p * 4);
      grp.current.rotation.y += 0.003;
    }
  });
  return (
    <group ref={grp}>
      <mesh>
        <sphereGeometry args={[3, 64, 64]} />
        <meshStandardMaterial color={0xb8855a} roughness={0.95} emissive={0x2a1004} />
      </mesh>
      {/* dust atmosphere */}
      <mesh>
        <sphereGeometry args={[3.15, 32, 32]} />
        <meshBasicMaterial color={0xd4a574} transparent opacity={0.15} side={THREE.BackSide} />
      </mesh>
    </group>
  );
}

function Endurance({ tIn, tOut }: { tIn: number; tOut: number }) {
  const grp = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    const t = clock.elapsedTime % LOOP;
    const on = t >= tIn && t <= tOut;
    if (grp.current) {
      grp.current.visible = on;
      const p = (t - tIn) / (tOut - tIn);
      grp.current.rotation.z = p * Math.PI * 1.6;
      grp.current.position.set(2.5, 0.5 - p * 0.3, -5);
    }
  });
  // Endurance-like ring of 12 modules
  const modules = useMemo(() => Array.from({ length: 12 }, (_, i) => i), []);
  return (
    <group ref={grp}>
      <mesh>
        <torusGeometry args={[0.9, 0.06, 16, 64]} />
        <meshStandardMaterial color={0xd0d6dc} metalness={0.7} roughness={0.4} />
      </mesh>
      {modules.map((i) => {
        const a = (i / modules.length) * Math.PI * 2;
        return (
          <mesh key={i} position={[Math.cos(a) * 0.9, Math.sin(a) * 0.9, 0]}>
            <boxGeometry args={[0.18, 0.18, 0.18]} />
            <meshStandardMaterial color={0xeef2f6} metalness={0.6} roughness={0.3} emissive={0x111927} />
          </mesh>
        );
      })}
    </group>
  );
}

function StarField() {
  const ref = useRef<THREE.Points>(null);
  const positions = useMemo(() => {
    const N = typeof window !== "undefined" && window.innerWidth < 768 ? 800 : 2200;
    const arr = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      arr[i * 3] = (Math.random() - 0.5) * 80;
      arr[i * 3 + 1] = (Math.random() - 0.5) * 50;
      arr[i * 3 + 2] = -Math.random() * 60 - 2;
    }
    return arr;
  }, []);
  useFrame((_, dt) => {
    if (ref.current) ref.current.rotation.z += dt * 0.01;
  });
  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} count={positions.length / 3} />
      </bufferGeometry>
      <pointsMaterial size={0.05} color={0xcfd8ff} transparent opacity={0.85} sizeAttenuation depthWrite={false} blending={THREE.AdditiveBlending} />
    </points>
  );
}

function CameraDrift() {
  useFrame(({ camera, clock }) => {
    const t = clock.elapsedTime;
    camera.position.x = Math.sin(t * 0.15) * 0.4;
    camera.position.y = Math.cos(t * 0.12) * 0.25;
    camera.lookAt(0, 0, -4);
  });
  return null;
}

// Cinematic captions timed to the 24s loop
const CAPTIONS = [
  { t: 1, d: 3.5, text: "Eles dizem que olhamos para o céu.", align: "left" },
  { t: 5.5, d: 3.5, text: "Mas nunca paramos de subir.", align: "right" },
  { t: 10, d: 3.5, text: "Atravesse o horizonte de eventos.", align: "left" },
  { t: 14.5, d: 3.5, text: "Encontre um novo mundo.", align: "right" },
  { t: 19, d: 4, text: "NexStationX · um trailer do cosmos", align: "center" },
];

export function InterstellarTrailer() {
  return (
    <section className="relative w-full h-[80vh] md:h-[90vh] overflow-hidden bg-black">
      <Canvas
        camera={{ position: [0, 0, 4], fov: 55 }}
        dpr={typeof window !== "undefined" && window.innerWidth < 768 ? 1 : [1, 1.5]}
        gl={{ antialias: true, powerPreference: "high-performance" }}
      >
        <color attach="background" args={[0x03040a]} />
        <fog attach="fog" args={[0x03040a, 10, 35]} />
        <ambientLight intensity={0.35} />
        <pointLight position={[5, 3, 3]} intensity={1.2} color={0xffd1a3} />
        <pointLight position={[-4, -2, 1]} intensity={0.5} color={0x88bbff} />

        <StarField />

        {/* timeline (seconds, 24s loop) */}
        <Wormhole tIn={0} tOut={5} />
        <Gargantua tIn={5} tOut={11} />
        <DustPlanet tIn={11} tOut={16} />
        <Endurance tIn={16} tOut={21} />
        <Gargantua tIn={21} tOut={24} />

        <CameraDrift />

        <EffectComposer>
          <Bloom intensity={1.4} luminanceThreshold={0.12} luminanceSmoothing={0.9} mipmapBlur />
          <ChromaticAberration offset={[0.0008, 0.0008] as unknown as [number, number]} radialModulation={false} modulationOffset={0} />
          <Noise opacity={0.07} />
          <Vignette eskil={false} offset={0.18} darkness={0.9} />
        </EffectComposer>
      </Canvas>

      {/* Letterbox bars (cinema 2.39:1 feel) */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[8%] bg-black" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[8%] bg-black" />

      {/* Top label */}
      <div className="pointer-events-none absolute top-[10%] left-6 md:left-10 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.4em] text-white/60">
        <span className="h-1.5 w-1.5 rounded-full bg-rose-500 animate-pulse" />
        Trailer · loop · 24s
      </div>

      {/* Center captions, time-synced via CSS keyframes-free polling */}
      <CaptionsOverlay />

      {/* Brand mark bottom */}
      <div className="pointer-events-none absolute bottom-[10%] right-6 md:right-10 text-right">
        <div className="font-mono text-[10px] uppercase tracking-[0.4em] text-white/50">apresenta</div>
        <div className="text-2xl md:text-4xl font-bold text-white" style={{ fontFamily: "'Space Grotesk', sans-serif", letterSpacing: "0.08em" }}>
          NEXSTATIONX
        </div>
      </div>
    </section>
  );
}

function CaptionsOverlay() {
  const [now, setNow] = useState(0);
  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const loop = (t: number) => {
      if (!document.hidden) setNow((t - start) / 1000);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);
  return (
    <div className="pointer-events-none absolute inset-0 flex items-center px-8 md:px-20">
      <AnimatePresence mode="wait">
        {CAPTIONS.map((c) => {
          const t = now % LOOP;
          if (t < c.t || t > c.t + c.d) return null;
          const align =
            c.align === "left"
              ? "text-left mr-auto"
              : c.align === "right"
                ? "text-right ml-auto"
                : "text-center mx-auto";
          return (
            <motion.h2
              key={c.text}
              initial={{ opacity: 0, y: 18, filter: "blur(10px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0, y: -10, filter: "blur(10px)" }}
              transition={{ duration: 1.3, ease: "easeOut" }}
              className={`max-w-[80%] md:max-w-[55%] text-white font-bold ${align}`}
              style={{
                fontFamily: "'Space Grotesk', sans-serif",
                fontSize: "clamp(1.5rem, 4vw, 3.5rem)",
                lineHeight: 1.1,
                textShadow: "0 2px 24px rgba(0,0,0,0.8), 0 0 40px rgba(108,71,255,0.25)",
                letterSpacing: "-0.01em",
              }}
            >
              {c.text}
            </motion.h2>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
