import { useEffect, useRef, useState } from "react";
import { useLocation } from "@tanstack/react-router";
import { Trophy, Award, X } from "lucide-react";
import { ALL_BADGES, loadCosmo, bumpVisit } from "@/lib/cosmoStore";

const ROUTE_TIPS: Record<string, string> = {
  "/": "Bem-vindo ao NexStationX! Pressione K em qualquer lugar para um fato secreto 🔑",
  "/sistema-solar": "Role para visitar cada planeta. Eu te aviso quando chegarmos 🌍",
  "/kepler-90": "Estamos a 2.545 anos-luz de casa. Sente a escala? ✨",
  "/comparacao": "Use o slider de escala — vai mudar como você vê o universo 🪐",
  "/exploracao": "Modo radical é meu favorito. Câmera bem dentro do espaço 🚀",
  "/asteroides": "Ative o mini-jogo no topo. Aposto que não passa de 30s! 🛸",
  "/descobertas": "Cada descoberta aqui mudou nossa visão do cosmos 🔭",
  "/curiosidades": "Filmes, jogos, cultura — o espaço também é arte 🎬",
  "/ao-vivo": "Olha! A ISS está passando agora mesmo sobre nós 📡",
  "/futuro": "Tudo isso vai acontecer enquanto você ainda estiver vivo 🛰️",
  "/linha-do-tempo": "Do Big Bang até hoje. Vamos juntos 🌌",
};

const PLANET_TIPS: Record<string, string> = {
  mercury: "Mercúrio — o mais rápido. 47 km/s sem nem suar 🔥",
  venus: "Cuidado: 462°C lá fora. Não esquece o protetor 🌋",
  earth: "Casa, doce casa. Único lugar com pizza confirmada 🌍",
  mars: "Marte! Aqui pousaram 5 rovers da NASA 🤖",
  jupiter: "Uau, você chegou em Júpiter! 95 luas te esperam 🪐",
  saturn: "Esses anéis têm só 10m de espessura mas 280 mil km 😱",
  uranus: "Urano gira deitado. Inverno dura 21 anos. ❄️",
  neptune: "Ventos de 2.100 km/h. O furacão eterno 💨",
};

export function CosmoGuide() {
  const mountRef = useRef<HTMLDivElement>(null);
  const location = useLocation();
  const [tip, setTip] = useState<string>(ROUTE_TIPS["/"]);
  const [visible, setVisible] = useState(true);
  const [showBadges, setShowBadges] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [, force] = useState(0);

  // Bump visit on mount
  useEffect(() => {
    bumpVisit();
    const s = loadCosmo();
    if (s.visits > 1 && s.visited.length > 0 && s.visited.length < 8) {
      setTimeout(() => {
        const missing = ["mercury","venus","earth","mars","jupiter","saturn","uranus","neptune"]
          .find((p) => !s.visited.includes(p));
        if (missing) setTip(`Bem-vindo de volta! Você ainda não visitou ${PLANET_TIPS[missing]?.split(" — ")[0] ?? missing} 👀`);
      }, 600);
    }
  }, []);

  // Re-render on cosmo update
  useEffect(() => {
    const onUpdate = () => force((n) => n + 1);
    window.addEventListener("cosmo:update", onUpdate);
    window.addEventListener("cosmo:badge", onUpdate);
    return () => {
      window.removeEventListener("cosmo:update", onUpdate);
      window.removeEventListener("cosmo:badge", onUpdate);
    };
  }, []);

  // Tip por rota
  useEffect(() => {
    const t = ROUTE_TIPS[location.pathname];
    if (t) setTip(t);
  }, [location.pathname]);

  // Tip por planeta visitado (custom event)
  useEffect(() => {
    const onPlanet = (e: Event) => {
      const id = (e as CustomEvent).detail as string;
      if (PLANET_TIPS[id]) setTip(PLANET_TIPS[id]);
    };
    window.addEventListener("cosmo:planet", onPlanet);
    return () => window.removeEventListener("cosmo:planet", onPlanet);
  }, []);

  // Reação ao scroll forte
  useEffect(() => {
    let last = 0;
    const onScroll = () => {
      const y = window.scrollY;
      if (Math.abs(y - last) > 800 && !scrolled) {
        setScrolled(true);
        setTip("Uau, você está voando pelo cosmos! 🌠");
        setTimeout(() => setScrolled(false), 4000);
      }
      last = y;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [scrolled]);

  const state = loadCosmo();

  if (!visible) {
    return (
      <button
        onClick={() => setVisible(true)}
        className="fixed bottom-4 right-4 z-40 glass rounded-full p-3 shadow-glow hover:scale-110 transition"
        aria-label="Abrir Cosmo"
      >
        🧑‍🚀
      </button>
    );
  }

  return (
    <>
      <div className="fixed bottom-4 right-4 z-40 flex items-end gap-3 pointer-events-none max-w-[90vw]">
        {tip && (
          <div className="pointer-events-auto max-w-[240px] glass rounded-2xl rounded-br-sm px-4 py-2.5 text-xs leading-snug shadow-card animate-fade-in">
            <div className="flex items-center justify-between gap-2 mb-1">
              <span className="font-mono text-[10px] uppercase tracking-widest text-primary/80">
                Cosmo · guia
              </span>
              <button
                onClick={() => setVisible(false)}
                className="text-muted-foreground hover:text-foreground"
                aria-label="Fechar guia"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
            <div className="text-foreground/90">{tip}</div>
            <button
              onClick={() => setShowBadges(true)}
              className="mt-2 inline-flex items-center gap-1 rounded-full bg-primary/15 px-2 py-1 text-[10px] font-mono uppercase tracking-wide text-primary hover:bg-primary/25"
            >
              <Trophy className="h-3 w-3" />
              {state.badges.length}/{ALL_BADGES.length} selos
            </button>
          </div>
        )}
        <button
          onClick={() => setShowBadges(true)}
          aria-label="Avatar Cosmo"
          className="pointer-events-auto relative h-[88px] w-[88px] cursor-pointer rounded-full glass shadow-glow overflow-hidden flex items-center justify-center"
        >
          <span className="absolute inset-0 rounded-full bg-primary/10 animate-pulse-glow" />
          <span className="relative text-5xl animate-float select-none">🧑‍🚀</span>
        </button>
      </div>

      {showBadges && (
        <div
          className="fixed inset-0 z-[70] bg-background/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setShowBadges(false)}
        >
          <div
            className="relative w-full max-w-md glass rounded-2xl p-6 shadow-glow"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setShowBadges(false)}
              className="absolute right-3 top-3 text-muted-foreground hover:text-foreground"
            >
              <X className="h-4 w-4" />
            </button>
            <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-primary mb-1">
              <Award className="h-3 w-3" /> Selos do Explorador
            </div>
            <h2 className="text-2xl font-bold text-gradient">Seu progresso</h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Visitas: {state.visits} · Planetas: {state.visited.length}/8 · Quiz: {state.quizScore} pts · Recorde nave: {state.highScore}s
            </p>
            <div className="mt-4 grid grid-cols-2 gap-2">
              {ALL_BADGES.map((b) => {
                const got = state.badges.includes(b.id);
                return (
                  <div
                    key={b.id}
                    className={`rounded-xl border p-3 text-xs flex items-start gap-2 ${
                      got
                        ? "border-primary/40 bg-primary/5"
                        : "border-border bg-secondary/20 opacity-50"
                    }`}
                  >
                    <span className="text-xl">{b.emoji}</span>
                    <div>
                      <div className="font-medium">{b.label}</div>
                      <div className="text-[10px] text-muted-foreground">{b.desc}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
