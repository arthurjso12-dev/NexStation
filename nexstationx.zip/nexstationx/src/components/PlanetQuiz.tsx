import { useState } from "react";
import { Check, X } from "lucide-react";
import { setQuizScore, awardBadge, loadCosmo } from "@/lib/cosmoStore";

type Q = { q: string; a: string[]; correct: number; explain: string };

const QUIZZES: Record<string, Q> = {
  mercury: {
    q: "Quanto dura um ano em Mercúrio?",
    a: ["88 dias", "1 ano terrestre", "176 dias"],
    correct: 0,
    explain: "Mercúrio orbita o Sol em apenas 88 dias terrestres.",
  },
  venus: {
    q: "Por que Vênus é o planeta mais quente?",
    a: ["Está mais perto do Sol", "Efeito estufa extremo", "Atividade vulcânica"],
    correct: 1,
    explain: "Sua atmosfera densa de CO₂ retém calor — chega a 462°C.",
  },
  earth: {
    q: "Qual a porcentagem da superfície coberta por água?",
    a: ["50%", "71%", "95%"],
    correct: 1,
    explain: "71% — somos o planeta azul.",
  },
  mars: {
    q: "Como se chama o maior vulcão de Marte?",
    a: ["Olympus Mons", "Mauna Kea", "Vesúvio"],
    correct: 0,
    explain: "Olympus Mons tem 22 km de altura — 2,5× o Everest.",
  },
  jupiter: {
    q: "Quantas luas conhecidas Júpiter tem?",
    a: ["12", "44", "95"],
    correct: 2,
    explain: "Júpiter tem 95 luas confirmadas — a maior coleção do Sistema Solar.",
  },
  saturn: {
    q: "Do que são feitos os anéis de Saturno?",
    a: ["Gás", "Gelo e rocha", "Poeira de cometas"],
    correct: 1,
    explain: "Bilhões de fragmentos de gelo e rocha — alguns do tamanho de casas.",
  },
  uranus: {
    q: "O que há de único na rotação de Urano?",
    a: ["Gira ao contrário", "Gira deitado (98°)", "Não gira"],
    correct: 1,
    explain: "Urano gira inclinado 98° — quase deitado em relação à órbita.",
  },
  neptune: {
    q: "Qual a velocidade dos ventos em Netuno?",
    a: ["500 km/h", "1.200 km/h", "2.100 km/h"],
    correct: 2,
    explain: "Os ventos mais rápidos do Sistema Solar — até 2.100 km/h.",
  },
};

export function PlanetQuiz({ planetId }: { planetId: string }) {
  const quiz = QUIZZES[planetId];
  const [picked, setPicked] = useState<number | null>(null);
  if (!quiz) return null;

  const choose = (i: number) => {
    if (picked !== null) return;
    setPicked(i);
    if (i === quiz.correct) {
      setQuizScore(1);
      const s = loadCosmo();
      if (s.quizScore >= 5) awardBadge("quiz_master");
    }
  };

  return (
    <div className="mt-5 rounded-xl border border-accent/30 bg-accent/5 p-4">
      <div className="font-mono text-[10px] uppercase tracking-widest text-accent mb-2">Quiz rápido</div>
      <p className="text-sm font-medium mb-3">{quiz.q}</p>
      <div className="space-y-1.5">
        {quiz.a.map((opt, i) => {
          const isCorrect = i === quiz.correct;
          const isPicked = picked === i;
          const reveal = picked !== null;
          return (
            <button
              key={i}
              onClick={() => choose(i)}
              disabled={reveal}
              className={`w-full text-left rounded-lg px-3 py-2 text-xs flex items-center justify-between transition ${
                reveal && isCorrect
                  ? "bg-emerald-500/15 border border-emerald-500/40 text-emerald-300"
                  : reveal && isPicked
                  ? "bg-rose-500/15 border border-rose-500/40 text-rose-300"
                  : "bg-secondary/40 border border-border hover:bg-secondary/70"
              }`}
            >
              <span>{opt}</span>
              {reveal && isCorrect && <Check className="h-3 w-3" />}
              {reveal && isPicked && !isCorrect && <X className="h-3 w-3" />}
            </button>
          );
        })}
      </div>
      {picked !== null && (
        <p className="mt-3 text-xs text-foreground/85 animate-fade-in">💡 {quiz.explain}</p>
      )}
    </div>
  );
}
