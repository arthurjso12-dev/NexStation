import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import type { Planet } from "@/lib/planets";
import { visitPlanet, awardBadge } from "@/lib/cosmoStore";

type Props = {
  planets: Planet[];
  focusedId?: string | null;
  onSelectPlanet?: (id: string) => void;
  onHoverPlanet?: (id: string | null) => void;
  starColor?: number;
  height?: string;
  /** "easy" = câmera ampla, foco didático. "radical" = imersão, mais perto, FOV largo. */
  mode?: "easy" | "radical";
  /** mostra cinturão de asteróides entre os rochosos e os gasosos */
  showAsteroidBelt?: boolean;
  /** Habilita rotular planetas com texto HTML overlay */
  showLabels?: boolean;
};

/**
 * SolarScene — three.js orbital simulation.
 * Realismo: texturas procedurais (continentes, bandas, crateras), bump simulado via emissive,
 * Sol em camadas com lensflare suave, anéis (Júpiter/Saturno-like), cinturão de asteróides,
 * inclinação orbital (eclíptica não plana), starfield 3D, fog atmosférica.
 *
 * Interação:
 * - Clique seleciona o planeta (callback `onSelectPlanet`).
 * - Hover destaca e dispara `onHoverPlanet`.
 * - Scroll-wheel ajusta zoom (não rola a página).
 * - Modo "radical" aproxima a câmera e amplia o FOV para imersão.
 */
export function SolarScene({
  planets,
  focusedId,
  onSelectPlanet,
  onHoverPlanet,
  starColor = 0xffcc66,
  height = "100vh",
  mode = "easy",
  showAsteroidBelt = false,
  showLabels = false,
}: Props) {
  const mountRef = useRef<HTMLDivElement>(null);
  const focusRef = useRef<string | null | undefined>(focusedId);
  const modeRef = useRef(mode);
  const [labels, setLabels] = useState<{ id: string; name: string; x: number; y: number; visible: boolean }[]>([]);

  useEffect(() => {
    focusRef.current = focusedId;
  }, [focusedId]);
  useEffect(() => {
    modeRef.current = mode;
  }, [mode]);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const width = mount.clientWidth;
    const heightPx = mount.clientHeight;

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x02030a, 0.0035);

    const camera = new THREE.PerspectiveCamera(50, width / heightPx, 0.1, 5000);
    camera.position.set(0, 45, 100);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, heightPx);
    renderer.setClearColor(0x000000, 0);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    mount.appendChild(renderer.domElement);

    // ===== Lights =====
    scene.add(new THREE.AmbientLight(0x223355, 0.32));
    const sunLight = new THREE.PointLight(0xffeecc, 4.2, 800, 1.4);
    sunLight.position.set(0, 0, 0);
    scene.add(sunLight);
    // Rim hemisphere for nicer terminator on planets
    scene.add(new THREE.HemisphereLight(0x6688aa, 0x000510, 0.18));

    // ===== Texture helpers =====
    const makeNoiseTexture = (
      base: string,
      accent: string,
      bands = false,
      size = 512,
      cratered = false
    ): THREE.CanvasTexture => {
      const canvas = document.createElement("canvas");
      canvas.width = size;
      canvas.height = size / 2;
      const ctx = canvas.getContext("2d")!;
      ctx.fillStyle = base;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      if (bands) {
        for (let y = 0; y < canvas.height; y += 3) {
          const t = Math.sin(y * 0.05 + Math.random()) * 0.5 + 0.5;
          ctx.fillStyle = t > 0.5 ? accent : base;
          ctx.globalAlpha = 0.18 + Math.random() * 0.3;
          ctx.fillRect(0, y, canvas.width, 3 + Math.random() * 7);
        }
        // turbulence swirls
        for (let i = 0; i < 25; i++) {
          ctx.globalAlpha = 0.25 + Math.random() * 0.3;
          ctx.fillStyle = i % 3 === 0 ? "#ffffff" : accent;
          ctx.beginPath();
          ctx.ellipse(
            Math.random() * canvas.width,
            Math.random() * canvas.height,
            10 + Math.random() * 30,
            3 + Math.random() * 8,
            0, 0, Math.PI * 2
          );
          ctx.fill();
        }
        ctx.globalAlpha = 1;
      }

      // Splotches
      for (let i = 0; i < 800; i++) {
        const x = Math.random() * canvas.width;
        const y = Math.random() * canvas.height;
        const r = Math.random() * 12 + 2;
        ctx.fillStyle = Math.random() > 0.5 ? accent : base;
        ctx.globalAlpha = Math.random() * 0.35;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
      }

      // Craters (rocky bodies)
      if (cratered) {
        for (let i = 0; i < 90; i++) {
          const x = Math.random() * canvas.width;
          const y = Math.random() * canvas.height;
          const r = 3 + Math.random() * 10;
          // shadow
          ctx.globalAlpha = 0.45;
          ctx.fillStyle = "#000000";
          ctx.beginPath();
          ctx.arc(x + 1, y + 1, r, 0, Math.PI * 2);
          ctx.fill();
          // rim
          ctx.globalAlpha = 0.55;
          ctx.strokeStyle = "#ffffff33";
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.arc(x, y, r, 0, Math.PI * 2);
          ctx.stroke();
        }
      }
      ctx.globalAlpha = 1;
      const tex = new THREE.CanvasTexture(canvas);
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
      tex.anisotropy = 4;
      return tex;
    };

    const makeEarthTexture = (): THREE.CanvasTexture => {
      const canvas = document.createElement("canvas");
      canvas.width = 1024;
      canvas.height = 512;
      const ctx = canvas.getContext("2d")!;
      const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
      grad.addColorStop(0, "#0a3a6b");
      grad.addColorStop(0.5, "#0f4d8c");
      grad.addColorStop(1, "#0a3a6b");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      for (let i = 0; i < 60; i++) {
        const cx = Math.random() * canvas.width;
        const cy = Math.random() * canvas.height;
        ctx.fillStyle = Math.random() > 0.7 ? "#3d6b3a" : "#2d5a2a";
        ctx.globalAlpha = 0.85;
        ctx.beginPath();
        for (let a = 0; a < Math.PI * 2; a += 0.3) {
          const r = 30 + Math.random() * 60;
          const px = cx + Math.cos(a) * r;
          const py = cy + Math.sin(a) * r * 0.6;
          if (a === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fill();
      }
      // sandy desert hints
      for (let i = 0; i < 30; i++) {
        ctx.globalAlpha = 0.35;
        ctx.fillStyle = "#c9a76b";
        ctx.beginPath();
        ctx.arc(Math.random() * canvas.width, Math.random() * canvas.height, 8 + Math.random() * 16, 0, Math.PI * 2);
        ctx.fill();
      }
      // Polar caps
      ctx.globalAlpha = 0.78;
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, canvas.width, 28);
      ctx.fillRect(0, canvas.height - 28, canvas.width, 28);
      // Clouds
      ctx.globalAlpha = 0.28;
      ctx.fillStyle = "#ffffff";
      for (let i = 0; i < 220; i++) {
        ctx.beginPath();
        ctx.arc(
          Math.random() * canvas.width,
          Math.random() * canvas.height,
          Math.random() * 25 + 5,
          0, Math.PI * 2
        );
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      const tex = new THREE.CanvasTexture(canvas);
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = 8;
      return tex;
    };

    // ===== Sun =====
    const sunGeo = new THREE.SphereGeometry(4.8, 64, 64);
    const sunMat = new THREE.MeshBasicMaterial({
      color: starColor,
      map: makeNoiseTexture("#ffaa33", "#ffee88", false, 512),
    });
    const sun = new THREE.Mesh(sunGeo, sunMat);
    sun.userData.isSun = true;
    scene.add(sun);
    sun.add(
      new THREE.Mesh(
        new THREE.SphereGeometry(6.2, 32, 32),
        new THREE.MeshBasicMaterial({ color: starColor, transparent: true, opacity: 0.22 })
      )
    );
    sun.add(
      new THREE.Mesh(
        new THREE.SphereGeometry(9.5, 32, 32),
        new THREE.MeshBasicMaterial({ color: starColor, transparent: true, opacity: 0.07 })
      )
    );

    // ===== Starfield (multi-layer for parallax depth) =====
    const makeStarLayer = (count: number, rMin: number, rMax: number, size: number, opacity: number) => {
      const geo = new THREE.BufferGeometry();
      const pos = new Float32Array(count * 3);
      const colors = new Float32Array(count * 3);
      for (let i = 0; i < count; i++) {
        const r = rMin + Math.random() * (rMax - rMin);
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.acos(2 * Math.random() - 1);
        pos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
        pos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
        pos[i * 3 + 2] = r * Math.cos(phi);
        // tinted (warm/cool stars)
        const tint = Math.random();
        colors[i * 3] = tint > 0.6 ? 1 : 0.7 + Math.random() * 0.3;
        colors[i * 3 + 1] = 0.8 + Math.random() * 0.2;
        colors[i * 3 + 2] = tint > 0.4 ? 1 : 0.85;
      }
      geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
      geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
      return new THREE.Points(
        geo,
        new THREE.PointsMaterial({
          size,
          vertexColors: true,
          sizeAttenuation: true,
          transparent: true,
          opacity,
          depthWrite: false,
        })
      );
    };
    const starsFar = makeStarLayer(2500, 800, 1500, 1.5, 0.85);
    const starsMid = makeStarLayer(900, 400, 700, 1.8, 0.75);
    const starsNear = makeStarLayer(300, 250, 380, 2.4, 0.6);
    scene.add(starsFar, starsMid, starsNear);

    // Subtle nebula clouds (large translucent sprites)
    const nebula = new THREE.Mesh(
      new THREE.SphereGeometry(1200, 32, 32),
      new THREE.MeshBasicMaterial({
        color: 0x331a55,
        side: THREE.BackSide,
        transparent: true,
        opacity: 0.18,
        depthWrite: false,
      })
    );
    scene.add(nebula);

    // ===== Scales =====
    const distScale = (au: number) => 10 + Math.log10(1 + au * 8) * 16;
    const radiusScale = (km: number) => 0.7 + Math.cbrt(km / 6371) * 1.25;

    type PlanetMesh = {
      id: string;
      name: string;
      mesh: THREE.Mesh;
      pivot: THREE.Object3D;
      glow: THREE.Mesh;
      angularSpeed: number;
      distance: number;
    };
    const planetMeshes: PlanetMesh[] = [];

    planets.forEach((p, i) => {
      const dist = distScale(p.distanceAU);
      const rad = radiusScale(p.radiusKm);

      // Slight orbital inclination per planet
      const inclination = (Math.random() - 0.5) * 0.18;

      // Orbit ring
      const ringGeo = new THREE.RingGeometry(dist - 0.05, dist + 0.05, 256);
      const ringMat = new THREE.MeshBasicMaterial({
        color: 0x4488ff,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.18,
      });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.x = -Math.PI / 2 + inclination;
      scene.add(ring);

      const pivot = new THREE.Object3D();
      pivot.rotation.y = (i / planets.length) * Math.PI * 2;
      pivot.rotation.x = inclination;
      scene.add(pivot);

      // Texture per planet
      let texture: THREE.Texture;
      const isEarth = p.id === "earth";
      const isJupiter = p.id === "jupiter" || p.type === "gasoso";
      const isMars = p.id === "mars";
      if (isEarth) {
        texture = makeEarthTexture();
      } else if (isJupiter) {
        texture = makeNoiseTexture(p.color, "#ffe2b0", true, 1024);
      } else if (isMars) {
        texture = makeNoiseTexture("#a8442a", "#5a1f10", false, 512, true);
      } else {
        texture = makeNoiseTexture(p.color, "#ffffff", false, 512, p.type === "rochoso");
      }

      const planetGeo = new THREE.SphereGeometry(rad, 96, 96);
      const planetMat = new THREE.MeshStandardMaterial({
        map: texture,
        bumpMap: texture,
        bumpScale: isJupiter ? 0.04 : 0.18,
        roughness: isJupiter ? 0.85 : 0.78,
        metalness: 0.08,
        emissive: new THREE.Color(p.color),
        emissiveIntensity: 0.06,
      });
      const mesh = new THREE.Mesh(planetGeo, planetMat);
      mesh.position.x = dist;
      mesh.userData.planetId = p.id;
      mesh.userData.planetName = p.name;
      mesh.rotation.z = (Math.random() - 0.5) * 0.5;
      pivot.add(mesh);

      // Selection / hover glow
      const glow = new THREE.Mesh(
        new THREE.SphereGeometry(rad * 1.18, 32, 32),
        new THREE.MeshBasicMaterial({
          color: p.color,
          transparent: true,
          opacity: 0,
          side: THREE.BackSide,
          depthWrite: false,
        })
      );
      mesh.add(glow);

      // Fresnel atmosphere shader — borda iluminada estilo NASA
      const atmoColor = new THREE.Color(isEarth ? 0x66aaff : isJupiter ? 0xffd9a0 : p.color);
      const atmoMat = new THREE.ShaderMaterial({
        uniforms: {
          glowColor: { value: atmoColor },
          intensity: { value: isEarth ? 1.4 : isJupiter ? 0.9 : 0.7 },
        },
        vertexShader: `
          varying vec3 vNormal;
          varying vec3 vPositionNormal;
          void main() {
            vNormal = normalize(normalMatrix * normal);
            vPositionNormal = normalize((modelViewMatrix * vec4(position, 1.0)).xyz);
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }
        `,
        fragmentShader: `
          uniform vec3 glowColor;
          uniform float intensity;
          varying vec3 vNormal;
          varying vec3 vPositionNormal;
          void main() {
            float fresnel = pow(1.0 - abs(dot(vNormal, -vPositionNormal)), 2.5);
            gl_FragColor = vec4(glowColor, fresnel * intensity);
          }
        `,
        side: THREE.BackSide,
        blending: THREE.AdditiveBlending,
        transparent: true,
        depthWrite: false,
      });
      const atmo = new THREE.Mesh(new THREE.SphereGeometry(rad * 1.12, 48, 48), atmoMat);
      mesh.add(atmo);

      // Saturn — anel proeminente e detalhado
      if (p.id === "saturn") {
        const ringG = new THREE.RingGeometry(rad * 1.4, rad * 2.6, 128);
        const ringM = new THREE.MeshBasicMaterial({
          color: 0xe8cfa0,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.85,
        });
        const r = new THREE.Mesh(ringG, ringM);
        r.rotation.x = -Math.PI / 2.2;
        mesh.add(r);
        // anel interno mais escuro
        const inner = new THREE.Mesh(
          new THREE.RingGeometry(rad * 1.25, rad * 1.38, 96),
          new THREE.MeshBasicMaterial({ color: 0xa88860, side: THREE.DoubleSide, transparent: true, opacity: 0.5 })
        );
        inner.rotation.x = -Math.PI / 2.2;
        mesh.add(inner);
      } else if (p.id === "uranus") {
        // Anéis verticais característicos de Urano
        const ringG = new THREE.RingGeometry(rad * 1.6, rad * 1.9, 96);
        const ringM = new THREE.MeshBasicMaterial({
          color: 0x88ccdd,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.45,
        });
        const r = new THREE.Mesh(ringG, ringM);
        r.rotation.x = -Math.PI / 2;
        r.rotation.y = Math.PI / 2.1;
        mesh.add(r);
      } else if (isJupiter) {
        const ringG = new THREE.RingGeometry(rad * 1.5, rad * 2.0, 96);
        const ringM = new THREE.MeshBasicMaterial({
          color: 0xc8a477,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.35,
        });
        const r = new THREE.Mesh(ringG, ringM);
        r.rotation.x = -Math.PI / 2.4;
        mesh.add(r);
      }

      const angularSpeed = (2 * Math.PI) / (p.periodDays / 8);
      planetMeshes.push({ id: p.id, name: p.name, mesh, pivot, glow, angularSpeed, distance: dist });
    });

    // ===== Asteroid belt =====
    if (showAsteroidBelt) {
      const beltCount = 1500;
      const beltGeo = new THREE.BufferGeometry();
      const beltPos = new Float32Array(beltCount * 3);
      const beltInner = distScale(2.2);
      const beltOuter = distScale(3.2);
      for (let i = 0; i < beltCount; i++) {
        const r = beltInner + Math.random() * (beltOuter - beltInner);
        const a = Math.random() * Math.PI * 2;
        beltPos[i * 3] = Math.cos(a) * r;
        beltPos[i * 3 + 1] = (Math.random() - 0.5) * 1.5;
        beltPos[i * 3 + 2] = Math.sin(a) * r;
      }
      beltGeo.setAttribute("position", new THREE.BufferAttribute(beltPos, 3));
      const belt = new THREE.Points(
        beltGeo,
        new THREE.PointsMaterial({
          color: 0xb89878,
          size: 0.35,
          sizeAttenuation: true,
          transparent: true,
          opacity: 0.85,
        })
      );
      scene.add(belt);
      // animate belt rotation
      (belt as any).userData.isBelt = true;
    }

    // ===== Raycaster (click + hover) =====
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    let hoveredId: string | null = null;

    const updatePointer = (event: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    };

    let sunClicks = 0;
    let sunClickTimer: ReturnType<typeof setTimeout> | null = null;
    let solarFlare: THREE.Mesh | null = null;
    const triggerFlare = () => {
      awardBadge("easter_sun");
      if (solarFlare) return;
      solarFlare = new THREE.Mesh(
        new THREE.SphereGeometry(6, 32, 32),
        new THREE.MeshBasicMaterial({ color: 0xff8833, transparent: true, opacity: 0.9 })
      );
      scene.add(solarFlare);
      const start = performance.now();
      const animFlare = () => {
        if (!solarFlare) return;
        const t = (performance.now() - start) / 1800;
        if (t >= 1) {
          scene.remove(solarFlare);
          (solarFlare.material as THREE.Material).dispose();
          solarFlare.geometry.dispose();
          solarFlare = null;
          return;
        }
        const s = 1 + t * 8;
        solarFlare.scale.setScalar(s);
        (solarFlare.material as THREE.MeshBasicMaterial).opacity = 0.9 * (1 - t);
        requestAnimationFrame(animFlare);
      };
      animFlare();
    };

    // Drag-to-rotate quando há foco
    let dragging = false;
    let dragStart = { x: 0, y: 0 };
    let downAt = 0;
    const handleDown = (e: MouseEvent) => {
      dragging = true;
      dragStart = { x: e.clientX, y: e.clientY };
      downAt = performance.now();
      renderer.domElement.style.cursor = focusRef.current ? "grabbing" : "grab";
    };
    const handleUp = (e: MouseEvent) => {
      dragging = false;
      const dt = performance.now() - downAt;
      const dx = Math.abs(e.clientX - dragStart.x);
      const dy = Math.abs(e.clientY - dragStart.y);
      // Click curto: trata seleção
      if (dt < 250 && dx < 4 && dy < 4) handleClick(e);
      renderer.domElement.style.cursor = "grab";
    };
    const handleClick = (event: MouseEvent) => {
      updatePointer(event);
      raycaster.setFromCamera(pointer, camera);
      // Sun easter egg
      const sunHit = raycaster.intersectObject(sun);
      if (sunHit.length > 0) {
        sunClicks += 1;
        if (sunClickTimer) clearTimeout(sunClickTimer);
        sunClickTimer = setTimeout(() => (sunClicks = 0), 1800);
        if (sunClicks >= 5) {
          sunClicks = 0;
          triggerFlare();
        }
        return;
      }
      const intersects = raycaster.intersectObjects(planetMeshes.map((p) => p.mesh));
      if (intersects.length > 0) {
        const id = intersects[0].object.userData.planetId as string;
        onSelectPlanet?.(id);
        visitPlanet(id);
        window.dispatchEvent(new CustomEvent("cosmo:planet", { detail: id }));
      }
    };
    const handleMove = (event: MouseEvent) => {
      if (dragging && focusRef.current) {
        const dx = event.clientX - dragStart.x;
        const dy = event.clientY - dragStart.y;
        const target = planetMeshes.find((p) => p.id === focusRef.current);
        if (target) {
          target.mesh.rotation.y += dx * 0.005;
          target.mesh.rotation.x += dy * 0.005;
        }
        dragStart = { x: event.clientX, y: event.clientY };
        return;
      }
      updatePointer(event);
      raycaster.setFromCamera(pointer, camera);
      const intersects = raycaster.intersectObjects(planetMeshes.map((p) => p.mesh));
      const id = intersects.length > 0 ? (intersects[0].object.userData.planetId as string) : null;
      if (id !== hoveredId) {
        hoveredId = id;
        renderer.domElement.style.cursor = id ? "pointer" : "grab";
        onHoverPlanet?.(id);
      }
    };
    renderer.domElement.addEventListener("mousedown", handleDown);
    renderer.domElement.addEventListener("mouseup", handleUp);
    renderer.domElement.addEventListener("mousemove", handleMove);

    // ===== Zoom via scroll (fixed — does NOT scroll the page) =====
    let zoom = 1;
    const minZoom = 0.35;
    const maxZoom = 2.8;
    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      const delta = e.deltaY > 0 ? 1.08 : 0.92;
      zoom = Math.min(maxZoom, Math.max(minZoom, zoom * delta));
    };
    renderer.domElement.addEventListener("wheel", handleWheel, { passive: false });

    // ===== Camera targets =====
    const defaultCamPos = new THREE.Vector3(0, 45, 100);
    const defaultLookAt = new THREE.Vector3(0, 0, 0);
    const desiredCamPos = defaultCamPos.clone();
    const desiredLookAt = defaultLookAt.clone();
    const currentLookAt = defaultLookAt.clone();

    let lastShootingTime = performance.now();
    let shootingStar: THREE.Line | null = null;
    const clock = new THREE.Clock();
    let frameId = 0;

    const animate = () => {
      const dt = clock.getDelta();
      const elapsed = clock.getElapsedTime();

      // Sun pulse + rotation
      sun.rotation.y += dt * 0.05;
      const pulse = 1 + Math.sin(elapsed * 1.5) * 0.04;
      sun.scale.setScalar(pulse);

      planetMeshes.forEach((pm) => {
        pm.pivot.rotation.y += pm.angularSpeed * dt * 0.5;
        pm.mesh.rotation.y += dt * 0.3;
        // Hover/focus glow modulation
        const glowMat = pm.glow.material as THREE.MeshBasicMaterial;
        const isFocus = focusRef.current === pm.id;
        const isHover = hoveredId === pm.id;
        const target = isFocus ? 0.5 : isHover ? 0.3 : 0;
        glowMat.opacity += (target - glowMat.opacity) * 0.12;
      });

      // Parallax star rotation
      starsFar.rotation.y += dt * 0.003;
      starsMid.rotation.y += dt * 0.006;
      starsNear.rotation.y += dt * 0.01;

      // Belt rotation
      scene.traverse((o) => {
        if ((o as any).userData?.isBelt) (o as THREE.Points).rotation.y += dt * 0.02;
      });

      const focusId = focusRef.current;
      const radical = modeRef.current === "radical";
      camera.fov = radical ? 65 : 50;
      camera.updateProjectionMatrix();

      if (focusId) {
        const target = planetMeshes.find((p) => p.id === focusId);
        if (target) {
          const worldPos = new THREE.Vector3();
          target.mesh.getWorldPosition(worldPos);
          const closeness = radical ? 4.5 : 8;
          const offset = new THREE.Vector3(
            Math.sin(elapsed * 0.15) * 1.5,
            radical ? 1.2 : 2.5,
            closeness * zoom
          );
          desiredCamPos.copy(worldPos).add(offset);
          desiredLookAt.copy(worldPos);
        }
      } else {
        const base = radical ? new THREE.Vector3(0, 25, 70) : defaultCamPos;
        desiredCamPos.copy(base).multiplyScalar(zoom);
        desiredLookAt.copy(defaultLookAt);
      }

      camera.position.lerp(desiredCamPos, 0.05);
      currentLookAt.lerp(desiredLookAt, 0.06);
      camera.lookAt(currentLookAt);

      // Shooting star every ~10s
      const now = performance.now();
      if (now - lastShootingTime > 10000 && !shootingStar) {
        lastShootingTime = now;
        const points = [
          new THREE.Vector3(80 + Math.random() * 40, 30 + Math.random() * 40, -50 - Math.random() * 50),
          new THREE.Vector3(50 + Math.random() * 20, 15 + Math.random() * 20, -40),
        ];
        const geo = new THREE.BufferGeometry().setFromPoints(points);
        const mat = new THREE.LineBasicMaterial({ color: 0xaaddff, transparent: true, opacity: 1 });
        shootingStar = new THREE.Line(geo, mat);
        scene.add(shootingStar);
        const startTime = now;
        const animateShoot = () => {
          if (!shootingStar) return;
          const t = (performance.now() - startTime) / 1500;
          if (t >= 1) {
            scene.remove(shootingStar);
            shootingStar.geometry.dispose();
            (shootingStar.material as THREE.Material).dispose();
            shootingStar = null;
            return;
          }
          shootingStar.position.x = -t * 120;
          shootingStar.position.y = -t * 50;
          (shootingStar.material as THREE.LineBasicMaterial).opacity = 1 - t;
          requestAnimationFrame(animateShoot);
        };
        animateShoot();
      }

      // Project planet positions to screen for HTML labels
      if (showLabels) {
        const next = planetMeshes.map((pm) => {
          const v = new THREE.Vector3();
          pm.mesh.getWorldPosition(v);
          v.project(camera);
          const x = (v.x * 0.5 + 0.5) * renderer.domElement.clientWidth;
          const y = (-v.y * 0.5 + 0.5) * renderer.domElement.clientHeight;
          const visible = v.z < 1;
          return { id: pm.id, name: pm.name, x, y, visible };
        });
        setLabels(next);
      }

      renderer.render(scene, camera);
      frameId = requestAnimationFrame(animate);
    };
    animate();

    const handleResize = () => {
      if (!mount) return;
      const w = mount.clientWidth;
      const h = mount.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener("resize", handleResize);

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener("resize", handleResize);
      renderer.domElement.removeEventListener("mousedown", handleDown);
      renderer.domElement.removeEventListener("mouseup", handleUp);
      renderer.domElement.removeEventListener("mousemove", handleMove);
      renderer.domElement.removeEventListener("wheel", handleWheel);
      mount.removeChild(renderer.domElement);
      renderer.dispose();
      scene.traverse((obj) => {
        if ((obj as THREE.Mesh).geometry) (obj as THREE.Mesh).geometry.dispose();
        const mat = (obj as THREE.Mesh).material;
        if (mat) {
          if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
          else (mat as THREE.Material).dispose();
        }
      });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [planets, starColor, showAsteroidBelt, showLabels]);

  return (
    <div className="relative w-full" style={{ height }}>
      <div
        ref={mountRef}
        style={{ width: "100%", height: "100%", touchAction: "none", overscrollBehavior: "contain" }}
        className="cursor-grab active:cursor-grabbing"
      />
      {showLabels &&
        labels.map((l) =>
          l.visible ? (
            <div
              key={l.id}
              className="pointer-events-none absolute font-mono text-[10px] uppercase tracking-widest text-primary/90 -translate-x-1/2 -translate-y-8"
              style={{ left: l.x, top: l.y, textShadow: "0 0 8px rgba(0,0,0,0.9)" }}
            >
              · {l.name} ·
            </div>
          ) : null
        )}
    </div>
  );
}
