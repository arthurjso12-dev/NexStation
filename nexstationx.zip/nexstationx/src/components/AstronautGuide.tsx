import { useEffect, useRef, useState } from "react";
import * as THREE from "three";

/**
 * AstronautGuide — astronauta 3D flutuante (Three.js puro, sem GLTF externo).
 * Construído com primitivas: capacete (esfera com visor reflectivo), torso, braços,
 * pernas e mochila PLSS. Flutua suavemente e gira para acompanhar o cursor.
 *
 * Renderizado em um canvas pequeno fixo (canto da viewport) servindo como guia visual.
 */
export function AstronautGuide({
  message,
  position = "br",
}: {
  message?: string;
  position?: "br" | "bl";
}) {
  const mountRef = useRef<HTMLDivElement>(null);
  const [tip, setTip] = useState(message ?? "Olá! Sou seu guia cósmico 🚀");
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    if (message) setTip(message);
  }, [message]);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;
    const w = mount.clientWidth;
    const h = mount.clientHeight;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, w / h, 0.1, 100);
    camera.position.set(0, 0.2, 5.6);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(w, h);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    mount.appendChild(renderer.domElement);

    scene.add(new THREE.AmbientLight(0x99bbff, 0.55));
    const key = new THREE.DirectionalLight(0xffffff, 1.4);
    key.position.set(3, 4, 5);
    scene.add(key);
    const rim = new THREE.PointLight(0x66ccff, 1.3, 12);
    rim.position.set(-3, 1, -2);
    scene.add(rim);

    const astro = new THREE.Group();
    scene.add(astro);

    const suitMat = new THREE.MeshStandardMaterial({
      color: 0xeef2ff,
      roughness: 0.55,
      metalness: 0.1,
    });
    const accentMat = new THREE.MeshStandardMaterial({
      color: 0xff8533,
      roughness: 0.4,
      metalness: 0.2,
    });
    const visorMat = new THREE.MeshStandardMaterial({
      color: 0x0a1a2a,
      roughness: 0.05,
      metalness: 0.95,
      emissive: 0x113355,
      emissiveIntensity: 0.6,
    });
    const helmetMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.25,
      metalness: 0.15,
    });

    // Capacete
    const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.6, 32, 32), helmetMat);
    helmet.position.y = 1.05;
    astro.add(helmet);

    // Visor (calota frontal)
    const visor = new THREE.Mesh(new THREE.SphereGeometry(0.52, 32, 32, 0, Math.PI * 2, 0.25, 1.0), visorMat);
    visor.position.set(0, 1.05, 0.05);
    astro.add(visor);

    // Reflexo no visor
    const shine = new THREE.Mesh(
      new THREE.SphereGeometry(0.08, 16, 16),
      new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.85 })
    );
    shine.position.set(-0.18, 1.18, 0.5);
    astro.add(shine);

    // Torso
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.45, 0.6, 8, 16), suitMat);
    torso.position.y = 0.15;
    astro.add(torso);

    // Mochila (PLSS)
    const backpack = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.85, 0.3), suitMat);
    backpack.position.set(0, 0.2, -0.4);
    astro.add(backpack);

    // Listra de acento no torso
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.1, 0.05), accentMat);
    stripe.position.set(0, 0.5, 0.42);
    astro.add(stripe);

    // Braços
    const armGeo = new THREE.CapsuleGeometry(0.14, 0.55, 6, 12);
    const armL = new THREE.Mesh(armGeo, suitMat);
    armL.position.set(-0.55, 0.2, 0);
    armL.rotation.z = 0.5;
    astro.add(armL);
    const armR = new THREE.Mesh(armGeo, suitMat);
    armR.position.set(0.55, 0.2, 0);
    armR.rotation.z = -0.5;
    astro.add(armR);

    // Luvas
    const gloveGeo = new THREE.SphereGeometry(0.16, 16, 16);
    const gloveL = new THREE.Mesh(gloveGeo, accentMat);
    gloveL.position.set(-0.85, -0.05, 0.05);
    astro.add(gloveL);
    const gloveR = new THREE.Mesh(gloveGeo, accentMat);
    gloveR.position.set(0.85, -0.05, 0.05);
    astro.add(gloveR);

    // Pernas
    const legGeo = new THREE.CapsuleGeometry(0.17, 0.6, 6, 12);
    const legL = new THREE.Mesh(legGeo, suitMat);
    legL.position.set(-0.22, -0.55, 0);
    astro.add(legL);
    const legR = new THREE.Mesh(legGeo, suitMat);
    legR.position.set(0.22, -0.55, 0);
    astro.add(legR);

    // Botas
    const bootGeo = new THREE.BoxGeometry(0.32, 0.18, 0.42);
    const bootL = new THREE.Mesh(bootGeo, accentMat);
    bootL.position.set(-0.22, -0.95, 0.06);
    astro.add(bootL);
    const bootR = new THREE.Mesh(bootGeo, accentMat);
    bootR.position.set(0.22, -0.95, 0.06);
    astro.add(bootR);

    // Antena pequena
    const antenna = new THREE.Mesh(
      new THREE.CylinderGeometry(0.015, 0.015, 0.25, 8),
      new THREE.MeshStandardMaterial({ color: 0x888888, metalness: 0.8, roughness: 0.3 })
    );
    antenna.position.set(0.4, 1.55, 0);
    antenna.rotation.z = -0.3;
    astro.add(antenna);
    const antennaTip = new THREE.Mesh(
      new THREE.SphereGeometry(0.04, 12, 12),
      new THREE.MeshStandardMaterial({ color: 0xff4444, emissive: 0xff2222, emissiveIntensity: 0.8 })
    );
    antennaTip.position.set(0.5, 1.65, 0);
    astro.add(antennaTip);

    // Estrelas pequenas atrás
    const starGeo = new THREE.BufferGeometry();
    const starPos = new Float32Array(80 * 3);
    for (let i = 0; i < 80; i++) {
      starPos[i * 3] = (Math.random() - 0.5) * 12;
      starPos[i * 3 + 1] = (Math.random() - 0.5) * 12;
      starPos[i * 3 + 2] = -3 - Math.random() * 4;
    }
    starGeo.setAttribute("position", new THREE.BufferAttribute(starPos, 3));
    scene.add(new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xffffff, size: 0.04 })));

    let mouseX = 0;
    let mouseY = 0;
    const onMove = (e: MouseEvent) => {
      mouseX = (e.clientX / window.innerWidth) * 2 - 1;
      mouseY = -(e.clientY / window.innerHeight) * 2 + 1;
    };
    window.addEventListener("mousemove", onMove);

    const clock = new THREE.Clock();
    let raf = 0;
    const tick = () => {
      const t = clock.getElapsedTime();
      astro.position.y = Math.sin(t * 1.2) * 0.12;
      astro.rotation.y = mouseX * 0.6 + Math.sin(t * 0.4) * 0.15;
      astro.rotation.x = mouseY * 0.2;
      armL.rotation.z = 0.5 + Math.sin(t * 1.5) * 0.08;
      armR.rotation.z = -0.5 - Math.sin(t * 1.5) * 0.08;
      antennaTip.scale.setScalar(1 + Math.sin(t * 4) * 0.25);
      renderer.render(scene, camera);
      raf = requestAnimationFrame(tick);
    };
    tick();

    const onResize = () => {
      const nw = mount.clientWidth;
      const nh = mount.clientHeight;
      camera.aspect = nw / nh;
      camera.updateProjectionMatrix();
      renderer.setSize(nw, nh);
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("resize", onResize);
      mount.removeChild(renderer.domElement);
      renderer.dispose();
      scene.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.geometry) m.geometry.dispose();
        if (m.material) {
          if (Array.isArray(m.material)) m.material.forEach((mm) => mm.dispose());
          else (m.material as THREE.Material).dispose();
        }
      });
    };
  }, []);

  if (!visible) return null;

  const pos = position === "bl" ? "left-4" : "right-4";
  return (
    <div className={`fixed bottom-4 ${pos} z-40 flex items-end gap-3 pointer-events-none`}>
      {tip && (
        <div className="pointer-events-auto max-w-[220px] glass rounded-2xl rounded-br-sm px-4 py-2.5 text-xs leading-snug shadow-card animate-fade-in">
          <div className="font-mono text-[10px] uppercase tracking-widest text-primary/80 mb-1">
            Guia · Cosmo
          </div>
          {tip}
          <button
            onClick={() => setVisible(false)}
            className="mt-2 block text-[10px] uppercase tracking-widest text-muted-foreground hover:text-primary transition"
          >
            fechar
          </button>
        </div>
      )}
      <div
        ref={mountRef}
        className="pointer-events-auto h-[150px] w-[120px] cursor-pointer drop-shadow-[0_0_20px_rgba(102,180,255,0.35)]"
        title="Seu guia astronauta"
      />
    </div>
  );
}
