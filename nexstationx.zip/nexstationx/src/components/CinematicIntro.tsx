import { useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { EffectComposer, Bloom, Vignette, Noise } from "@react-three/postprocessing";
import { AnimatePresence, motion } from "framer-motion";
import * as THREE from "three";
import gsap from "gsap";

const INTRO_KEY = "nexstationx.intro.v1";

// ---------- Warp starfield ----------
function WarpStars({ count, speed }: { count: number; speed: number }) {
  const ref = useRef<THREE.Points>(null);
  const positions = useMemo(() => {
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      arr[i * 3] = (Math.random() - 0.5) * 60;
      arr[i * 3 + 1] = (Math.random() - 0.5) * 60;
      arr[i * 3 + 2] = -Math.random() * 200;
    }
    return arr;
  }, [count]);

  useFrame((_, dt) => {
    const pts = ref.current;
    if (!pts) return;
    const arr = (pts.geometry.attributes.position as THREE.BufferAttribute).array as Float32Array;
    for (let i = 0; i < count; i++) {
      arr[i * 3 + 2] += dt * speed * (40 + Math.random() * 10);
      if (arr[i * 3 + 2] > 5) {
        arr[i * 3] = (Math.random() - 0.5) * 60;
        arr[i * 3 + 1] = (Math.random() - 0.5) * 60;
        arr[i * 3 + 2] = -200;
      }
    }
    (pts.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    pts.rotation.z += dt * 0.02;
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
          count={positions.length / 3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.18}
        color={0xb8d4ff}
        transparent
        opacity={0.9}
        sizeAttenuation
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

// ---------- Black hole / accretion disk ----------
function BlackHole({ visible }: { visible: boolean }) {
  const disk = useRef<THREE.Mesh>(null);
  const halo = useRef<THREE.Mesh>(null);
  useFrame((_, dt) => {
    if (disk.current) disk.current.rotation.z += dt * 0.4;
    if (halo.current) {
      const s = 1 + Math.sin(performance.now() * 0.002) * 0.05;
      halo.current.scale.set(s, s, 1);
    }
  });
  if (!visible) return null;
  return (
    <group position={[0, 0, -8]}>
      <mesh>
        <sphereGeometry args={[1.4, 64, 64]} />
        <meshBasicMaterial color={0x000000} />
      </mesh>
      <mesh ref={halo}>
        <ringGeometry args={[1.45, 1.6, 128]} />
        <meshBasicMaterial
          color={0xffd166}
          side={THREE.DoubleSide}
          transparent
          opacity={0.9}
          blending={THREE.AdditiveBlending}
        />
      </mesh>
      <mesh ref={disk} rotation={[Math.PI / 2.3, 0, 0]}>
        <ringGeometry args={[1.7, 5, 128]} />
        <meshBasicMaterial
          color={0xff8a3c}
          side={THREE.DoubleSide}
          transparent
          opacity={0.55}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
        />
      </mesh>
    </group>
  );
}

// ---------- Giant planet flyby ----------
function GiantPlanet({ start, end }: { start: number; end: number }) {
  const ref = useRef<THREE.Mesh>(null);
  const startTime = useRef<number | null>(null);
  useFrame(({ clock }) => {
    if (!ref.current) return;
    const t = clock.elapsedTime;
    if (t < start || t > end) {
      ref.current.visible = false;
      return;
    }
    ref.current.visible = true;
    if (startTime.current == null) startTime.current = t;
    const p = (t - start) / (end - start);
    ref.current.position.set(-8 + p * 16, -1 + p * 0.5, -10 + p * 8);
    ref.current.rotation.y += 0.005;
  });
  return (
    <mesh ref={ref}>
      <sphereGeometry args={[3.2, 64, 64]} />
      <meshStandardMaterial color={0xc97a3a} roughness={0.8} emissive={0x331100} />
    </mesh>
  );
}

// ---------- Magnetic 3D text (final scene) ----------
function MagneticText({ text }: { text: string }) {
  const group = useRef<THREE.Group>(null);
  const { mouse, viewport } = useThree();

  const points = useMemo(() => {
    const canvas = document.createElement("canvas");
    const W = 1024;
    const H = 160;
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext("2d")!;
    ctx.fillStyle = "#fff";
    ctx.font = "bold 90px 'Space Grotesk', sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(text, W / 2, H / 2);
    const img = ctx.getImageData(0, 0, W, H).data;
    const pts: number[] = [];
    const step = 4;
    for (let y = 0; y < H; y += step) {
      for (let x = 0; x < W; x += step) {
        const i = (y * W + x) * 4;
        if (img[i + 3] > 128) {
          pts.push((x - W / 2) * 0.012, -(y - H / 2) * 0.012, (Math.random() - 0.5) * 0.4);
        }
      }
    }
    return new Float32Array(pts);
  }, [text]);

  useFrame((_, dt) => {
    if (!group.current) return;
    const tx = mouse.x * viewport.width * 0.04;
    const ty = mouse.y * viewport.height * 0.04;
    group.current.position.x += (tx - group.current.position.x) * 0.05;
    group.current.position.y += (ty - group.current.position.y) * 0.05;
    group.current.rotation.y = mouse.x * 0.3;
    group.current.rotation.x = -mouse.y * 0.15;
    group.current.children.forEach((c) => {
      c.rotation.z += dt * 0.05;
    });
  });

  return (
    <group ref={group}>
      <points>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[points, 3]} count={points.length / 3} />
        </bufferGeometry>
        <pointsMaterial
          size={0.06}
          color={0xffd166}
          transparent
          opacity={1}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
          sizeAttenuation
        />
      </points>
    </group>
  );
}

// ---------- Scene orchestrator ----------
function IntroScene({ phase }: { phase: number }) {
  // phases: 0 warp, 1 blackhole, 2 planet flyby, 3 final text
  const isMobile = typeof window !== "undefined" && window.innerWidth < 768;
  const starCount = isMobile ? 600 : 1800;
  return (
    <>
      <color attach="background" args={[0x05030f]} />
      <fog attach="fog" args={[0x05030f, 8, 40]} />
      <ambientLight intensity={0.4} />
      <pointLight position={[0, 5, 5]} intensity={1.2} color={0x88bbff} />

      <WarpStars count={starCount} speed={phase === 0 ? 2.5 : phase === 3 ? 0.4 : 1} />
      <BlackHole visible={phase === 1} />
      {phase === 2 && <GiantPlanet start={0} end={5} />}
      {phase === 3 && <MagneticText text="O universo está esperando por você." />}

      <EffectComposer>
        <Bloom intensity={1.2} luminanceThreshold={0.15} luminanceSmoothing={0.9} mipmapBlur />
        <Noise opacity={0.05} />
        <Vignette eskil={false} offset={0.2} darkness={0.85} />
      </EffectComposer>
    </>
  );
}

const CAPTIONS = [
  { t: 0.5, d: 3, text: "A humanidade sempre olhou para as estrelas." },
  { t: 4, d: 3, text: "Agora é hora de explorá-las." },
  { t: 7.5, d: 2.8, text: "Bem-vindo ao NexStationX." },
];

export function CinematicIntro() {
  const [mounted, setMounted] = useState(false);
  const [show, setShow] = useState(false);
  const [phase, setPhase] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [finalIn, setFinalIn] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setMounted(true);
    try {
      const seen = localStorage.getItem(INTRO_KEY);
      if (!seen) setShow(true);
    } catch {
      /* no-op */
    }
  }, []);

  // FPS throttle when tab hidden — pause via CSS by hiding canvas
  useEffect(() => {
    if (!show) return;
    let raf = 0;
    let start = performance.now();
    let last = start;
    const tick = (now: number) => {
      const dt = (now - last) / 1000;
      last = now;
      if (!document.hidden) {
        setElapsed((e) => {
          const next = e + dt;
          if (next < 3) setPhase(0);
          else if (next < 6) setPhase(1);
          else if (next < 10) setPhase(2);
          else {
            setPhase(3);
            setFinalIn(true);
          }
          return next;
        });
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [show]);

  const dismiss = () => {
    try {
      localStorage.setItem(INTRO_KEY, "1");
    } catch {
      /* no-op */
    }
    if (containerRef.current) {
      gsap.to(containerRef.current, {
        opacity: 0,
        duration: 0.9,
        ease: "power2.inOut",
        onComplete: () => setShow(false),
      });
    } else {
      setShow(false);
    }
  };

  if (!mounted || !show) return null;

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-[200] bg-black"
      style={{ pointerEvents: "auto" }}
    >
      <Canvas
        camera={{ position: [0, 0, 6], fov: 60 }}
        dpr={typeof window !== "undefined" && window.innerWidth < 768 ? 1 : [1, 1.5]}
        gl={{ antialias: true, powerPreference: "high-performance" }}
      >
        <IntroScene phase={phase} />
      </Canvas>

      {/* Skip button */}
      <button
        onClick={dismiss}
        className="absolute top-5 right-5 z-10 rounded-full border border-white/20 bg-white/5 px-4 py-1.5 text-[11px] font-mono uppercase tracking-widest text-white/70 hover:bg-white/15 hover:text-white transition backdrop-blur-sm"
      >
        Pular intro
      </button>

      {/* Captions */}
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center px-6">
        <AnimatePresence mode="wait">
          {CAPTIONS.map(
            (c) =>
              elapsed >= c.t &&
              elapsed < c.t + c.d && (
                <motion.h2
                  key={c.text}
                  initial={{ opacity: 0, y: 20, filter: "blur(8px)" }}
                  animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                  exit={{ opacity: 0, y: -10, filter: "blur(8px)" }}
                  transition={{ duration: 1.2, ease: "easeOut" }}
                  className="text-center text-2xl md:text-5xl font-bold tracking-wide text-white"
                  style={{
                    fontFamily: "'Space Grotesk', sans-serif",
                    textShadow: "0 0 24px rgba(108,71,255,0.6), 0 0 60px rgba(255,209,102,0.25)",
                  }}
                >
                  {c.text}
                </motion.h2>
              ),
          )}
        </AnimatePresence>
      </div>

      {/* Final CTA */}
      <AnimatePresence>
        {finalIn && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2, duration: 1.2 }}
            className="absolute inset-x-0 bottom-16 flex justify-center"
          >
            <button
              onClick={dismiss}
              className="group relative overflow-hidden rounded-full border border-[#FFD166]/60 bg-gradient-to-r from-[#6C47FF]/30 to-[#FFD166]/20 px-8 py-3 text-sm font-semibold tracking-widest text-white uppercase backdrop-blur-md transition hover:scale-105"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              <span className="relative z-10">▸ Iniciar Exploração</span>
              <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top progress */}
      <div className="absolute top-0 left-0 right-0 h-[2px] bg-white/10">
        <div
          className="h-full bg-gradient-to-r from-[#6C47FF] to-[#FFD166] transition-[width] duration-200"
          style={{ width: `${Math.min(100, (elapsed / 12) * 100)}%` }}
        />
      </div>
    </div>
  );
}
