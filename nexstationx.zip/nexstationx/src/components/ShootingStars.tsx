import { useEffect, useState } from "react";

type StaticStar = {
  top: number;
  left: number;
  size: number;
  delay: number;
  opacity: number;
};

/**
 * Camada DOM de estrelas cadentes — usada em fundos de descrição.
 * Estrelas geradas no cliente para evitar mismatch de hidratação.
 */
export function ShootingStars() {
  const [twinkles, setTwinkles] = useState<StaticStar[]>([]);
  const [stars, setStars] = useState<{ id: number; top: number; left: number }[]>([]);

  useEffect(() => {
    setTwinkles(
      Array.from({ length: 40 }).map(() => ({
        top: Math.random() * 100,
        left: Math.random() * 100,
        size: Math.random() * 2 + 1,
        delay: Math.random() * 3,
        opacity: 0.4 + Math.random() * 0.5,
      }))
    );

    const trigger = () => {
      const id = Date.now();
      setStars((s) => [
        ...s,
        { id, top: Math.random() * 40, left: 60 + Math.random() * 40 },
      ]);
      setTimeout(() => setStars((s) => s.filter((x) => x.id !== id)), 2500);
    };
    trigger();
    const interval = setInterval(trigger, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {twinkles.map((s, i) => (
        <span
          key={i}
          className="absolute rounded-full bg-white animate-twinkle"
          style={{
            top: `${s.top}%`,
            left: `${s.left}%`,
            width: `${s.size}px`,
            height: `${s.size}px`,
            animationDelay: `${s.delay}s`,
            opacity: s.opacity,
          }}
        />
      ))}
      {stars.map((s) => (
        <span
          key={s.id}
          className="absolute h-px w-32 animate-shooting"
          style={{
            top: `${s.top}%`,
            left: `${s.left}%`,
            background: "linear-gradient(90deg, transparent, oklch(0.85 0.18 220), white)",
            boxShadow: "0 0 8px oklch(0.85 0.18 220)",
          }}
        />
      ))}
    </div>
  );
}
